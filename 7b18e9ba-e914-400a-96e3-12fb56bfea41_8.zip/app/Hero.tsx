
'use client';

import Link from 'next/link';

export default function Hero() {
  return (
    <section 
      className="relative min-h-screen flex items-center bg-cover bg-center"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Modern%20textile%20manufacturing%20facility%20with%20high-speed%20weaving%20machines%20in%20operation%2C%20industrial%20setting%20with%20clean%20white%20floors%20and%20professional%20lighting%2C%20workers%20in%20safety%20gear%20operating%20advanced%20textile%20equipment%2C%20rolls%20of%20premium%20fabric%20in%20various%20colors%2C%20professional%20corporate%20environment%20showcasing%20manufacturing%20excellence%20and%20precision%2C%20clean%20minimalist%20industrial%20aesthetic%20with%20blue%20and%20white%20color%20scheme&width=1920&height=1080&seq=hero1&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 via-blue-800/70 to-transparent"></div>
      
      <div className="relative z-10 mx-auto px-6 w-full">
        <div className="max-w-3xl">
          <h1 className="text-5xl md:text-6xl font-bold text-white leading-tight mb-6">
            Global Textile Solutions Since 1995
          </h1>
          <p className="text-xl md:text-2xl text-blue-100 mb-4 font-medium">
            98% On-Time Delivery
          </p>
          <p className="text-lg text-blue-50 mb-8 max-w-2xl leading-relaxed">
            Premium fabrics for fashion, sportswear & medical textiles. Advanced manufacturing with cutting-edge technology and sustainable practices.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/consultation" className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-700 transition-all transform hover:scale-105 shadow-lg whitespace-nowrap cursor-pointer text-center">
              Get Instant Quote
            </Link>
            <Link href="/products" className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white/20 transition-all border border-white/30 whitespace-nowrap cursor-pointer text-center">
              Book Product Tour
            </Link>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/70 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
}
