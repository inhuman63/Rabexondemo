
'use client';

export default function Stats() {
  const stats = [
    { number: '29+', label: 'Years Experience', icon: 'ri-calendar-line' },
    { number: '98%', label: 'On-Time Delivery', icon: 'ri-time-line' },
    { number: '150+', label: 'Global Clients', icon: 'ri-global-line' },
    { number: '50M+', label: 'Meters Produced', icon: 'ri-ruler-line' }
  ];

  return (
    <section className="py-16 bg-blue-50">
      <div className="mx-auto px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 flex items-center justify-center bg-blue-100 rounded-full mx-auto mb-4">
                <i className={`${stat.icon} text-2xl text-blue-700`}></i>
              </div>
              <div className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                {stat.number}
              </div>
              <div className="text-gray-600 font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
