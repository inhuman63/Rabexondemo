'use client';

import { useState, useEffect } from 'react';

export default function ClientProof() {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      quote: "Rabexon delivered 98.7% defect-free fabric for our luxury line. Their attention to detail and quality consistency is unmatched in the industry.",
      author: "Emma Laurent",
      position: "VP Sourcing",
      company: "LVMH",
      logo: "https://readdy.ai/api/search-image?query=LVMH%20luxury%20fashion%20brand%20logo%20in%20professional%20corporate%20style%2C%20premium%20fashion%20house%20branding%2C%20elegant%20luxury%20brand%20identity&width=120&height=60&seq=lvmh1&orientation=landscape",
      metrics: "98.7% defect-free rate"
    },
    {
      quote: "The AI-powered quality control system has revolutionized our production standards. Delivery times improved by 35% while maintaining premium quality.",
      author: "James Mitchell",
      position: "Head of Procurement",
      company: "Nike",
      logo: "https://readdy.ai/api/search-image?query=Nike%20swoosh%20logo%20in%20professional%20corporate%20format%2C%20athletic%20sportswear%20brand%20identity%2C%20clean%20brand%20logo%20design&width=120&height=60&seq=nike1&orientation=landscape",
      metrics: "35% faster delivery"
    },
    {
      quote: "Sustainable practices and OEKO-TEX certification align perfectly with our brand values. Rabexon is our trusted partner for eco-friendly textiles.",
      author: "Sophie Anderson",
      position: "Sustainability Director",
      company: "Patagonia",
      logo: "https://readdy.ai/api/search-image?query=Patagonia%20outdoor%20brand%20logo%20in%20corporate%20style%2C%20sustainable%20outdoor%20clothing%20brand%20identity%2C%20environmental%20brand%20logo&width=120&height=60&seq=patagonia1&orientation=landscape",
      metrics: "100% sustainable sourcing"
    },
    {
      quote: "Their global supply chain expertise enabled us to expand into 12 new markets seamlessly. Outstanding logistics and quality control.",
      author: "David Chen",
      position: "Global Operations Manager",
      company: "Uniqlo",
      logo: "https://readdy.ai/api/search-image?query=Uniqlo%20brand%20logo%20in%20professional%20corporate%20format%2C%20Japanese%20retail%20fashion%20brand%20identity%2C%20clean%20minimal%20brand%20logo&width=120&height=60&seq=uniqlo1&orientation=landscape",
      metrics: "12 new markets"
    }
  ];

  const clientLogos = [
    { name: "H&M", logo: "https://readdy.ai/api/search-image?query=H&M fashion retail brand logo, Swedish clothing company brand identity&width=100&height=50&seq=hm1&orientation=landscape" },
    { name: "Zara", logo: "https://readdy.ai/api/search-image?query=Zara%20fashion%20brand%20logo%2C%20Spanish%20clothing%20retailer%20brand%20identity&width=100&height=50&seq=zara1&orientation=landscape" },
    { name: "Gap", logo: "https://readdy.ai/api/search-image?query=Gap%20clothing%20brand%20logo%2C%20American%20clothing%20retailer%20brand%20identity&width=100&height=50&seq=gap1&orientation=landscape" },
    { name: "Adidas", logo: "https://readdy.ai/api/search-image?query=Adidas%20three%20stripes%20logo%2C%20German%20sportswear%20brand%20identity&width=100&height=50&seq=adidas1&orientation=landscape" },
    { name: "Puma", logo: "https://readdy.ai/api/search-image?query=Puma%20cat%20logo%2C%20German%20sportswear%20brand%20identity&width=100&height=50&seq=puma1&orientation=landscape" },
    { name: "Under Armour", logo: "https://readdy.ai/api/search-image?query=Under%20Armour%20brand%20logo%2C%20American%20sportswear%20company%20brand%20identity&width=100&height=50&seq=ua1&orientation=landscape" }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  return (
    <section className="py-20 bg-white">
      <div className="mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Trusted by Global Leaders
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See what industry leaders say about our textile solutions and partnership experience
          </p>
        </div>

        <div className="max-w-4xl mx-auto mb-16">
          <div className="bg-blue-50 rounded-3xl p-12 relative overflow-hidden">
            <div className="absolute top-8 left-8 w-16 h-16 flex items-center justify-center bg-blue-100 rounded-full">
              <i className="ri-double-quotes-l text-2xl text-blue-700"></i>
            </div>
            
            <div className="relative z-10">
              <div className="mb-8">
                <p className="text-2xl text-gray-900 leading-relaxed font-medium italic">
                  "{testimonials[currentTestimonial].quote}"
                </p>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <img 
                    src={testimonials[currentTestimonial].logo}
                    alt={testimonials[currentTestimonial].company}
                    className="h-12 w-auto object-contain"
                  />
                  <div>
                    <div className="font-bold text-gray-900">
                      {testimonials[currentTestimonial].author}
                    </div>
                    <div className="text-gray-600">
                      {testimonials[currentTestimonial].position}, {testimonials[currentTestimonial].company}
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
                    {testimonials[currentTestimonial].metrics}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-center space-x-2 mt-6">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTestimonial(index)}
                className={`w-3 h-3 rounded-full transition-all cursor-pointer ${
                  currentTestimonial === index ? 'bg-blue-600' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">
            Partnering with Industry Giants
          </h3>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center">
            {clientLogos.map((client, index) => (
              <div key={index} className="flex items-center justify-center">
                <img 
                  src={client.logo}
                  alt={client.name}
                  className="h-8 w-auto object-contain opacity-60 hover:opacity-100 transition-opacity"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-3xl p-12 text-center text-white">
          <h3 className="text-3xl font-bold mb-6">
            Join 200+ Global Brands
          </h3>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto leading-relaxed">
            Experience the same quality, reliability, and innovation that industry leaders trust for their textile needs.
          </p>
          <button className="bg-white text-blue-700 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-colors whitespace-nowrap cursor-pointer">
            Become a Partner
          </button>
        </div>
      </div>
    </section>
  );
}