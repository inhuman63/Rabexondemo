'use client';

import { useState, useEffect } from 'react';

export default function TrustMetrics() {
  const [currentCount, setCurrentCount] = useState(12845000);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentCount(prev => prev + Math.floor(Math.random() * 5) + 1);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const metrics = [
    {
      icon: 'ri-truck-line',
      number: '98%',
      label: 'On-Time Delivery',
      description: 'Consistent global logistics performance'
    },
    {
      icon: 'ri-shield-check-line',
      number: '100%',
      label: 'OEKO-TEX® Certified',
      description: 'Environmental and safety standards'
    },
    {
      icon: 'ri-global-line',
      number: '45',
      label: 'Countries',
      description: 'International market presence'
    },
    {
      icon: 'ri-award-line',
      number: '30+',
      label: 'Years Experience',
      description: 'Industry leadership and expertise'
    }
  ];

  return (
    <section className="py-20 bg-blue-50">
      <div className="mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Built on Trust & Excellence
          </h2>
          <div className="bg-white rounded-2xl p-8 shadow-lg max-w-md mx-auto mb-12">
            <div className="flex items-center justify-center mb-4">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse mr-3"></div>
              <span className="text-gray-600 font-medium">Live Production Counter</span>
            </div>
            <div className="text-4xl font-bold text-blue-700 mb-2" suppressHydrationWarning={true}>
              {currentCount.toLocaleString()}
            </div>
            <div className="text-gray-600">Meters shipped this year</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow text-center">
              <div className="w-16 h-16 flex items-center justify-center bg-blue-100 rounded-full mx-auto mb-6">
                <i className={`${metric.icon} text-2xl text-blue-700`}></i>
              </div>
              <div className="text-4xl font-bold text-gray-900 mb-2">
                {metric.number}
              </div>
              <div className="text-lg font-semibold text-gray-900 mb-3">
                {metric.label}
              </div>
              <div className="text-gray-600 text-sm leading-relaxed">
                {metric.description}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}