'use client';

import { useRef, useEffect, useState } from 'react';

export default function CompanyTimeline() {
  const scrollContainerRef = useRef(null);
  const [selectedMilestone, setSelectedMilestone] = useState(0);

  const milestones = [
    {
      year: '1992',
      title: 'Foundation in Osaka',
      description: 'Started as a specialized dyeing facility with 3 traditional looms and a vision for quality excellence',
      image: 'https://readdy.ai/api/search-image?query=Vintage%20textile%20factory%20from%201990s%20showing%20traditional%20weaving%20looms%20and%20dyeing%20equipment%2C%20historical%20textile%20manufacturing%20facility%20in%20Japan%2C%20classic%20industrial%20textile%20machinery%20in%20retro%20setting%2C%20nostalgic%20factory%20environment%20with%20workers&width=600&height=400&seq=timeline1&orientation=landscape',
      icon: 'ri-building-line'
    },
    {
      year: '1998',
      title: 'Global Expansion',
      description: 'Opened first international facility in Thailand, establishing our multi-country production network',
      image: 'https://readdy.ai/api/search-image?query=International%20textile%20manufacturing%20facility%20expansion%20in%20Thailand%2C%20modern%20textile%20factory%20with%20advanced%20machinery%2C%20global%20textile%20production%20facility%20with%20international%20standards%2C%20professional%20textile%20manufacturing%20environment&width=600&height=400&seq=timeline2&orientation=landscape',
      icon: 'ri-earth-line'
    },
    {
      year: '2005',
      title: 'First GOTS Certification',
      description: 'Achieved Global Organic Textile Standard certification, pioneering sustainable textile production',
      image: 'https://readdy.ai/api/search-image?query=GOTS%20certification%20ceremony%20with%20textile%20quality%20control%20documents%20and%20organic%20cotton%20fabrics%2C%20sustainable%20textile%20manufacturing%20certification%2C%20eco-friendly%20textile%20production%20facility%20with%20green%20certifications%20displayed&width=600&height=400&seq=timeline3&orientation=landscape',
      icon: 'ri-leaf-line'
    },
    {
      year: '2012',
      title: 'Smart Factory Initiative',
      description: 'Implemented IoT sensors and automated quality control systems across all production facilities',
      image: 'https://readdy.ai/api/search-image?query=Smart%20textile%20factory%20with%20IoT%20sensors%20and%20automated%20quality%20control%20systems%2C%20advanced%20manufacturing%20technology%2C%20digital%20textile%20production%20monitoring%20systems%2C%20modern%20industrial%20automation%20in%20textile%20facility&width=600&height=400&seq=timeline4&orientation=landscape',
      icon: 'ri-robot-line'
    },
    {
      year: '2018',
      title: '200th Brand Partnership',
      description: 'Reached milestone of serving 200 global fashion and textile brands across 45 countries',
      image: 'https://readdy.ai/api/search-image?query=Global%20textile%20brand%20partnership%20celebration%20with%20international%20fashion%20brands%20logos%20and%20textile%20samples%2C%20diverse%20fashion%20brand%20collaborations%2C%20professional%20textile%20industry%20networking%20event&width=600&height=400&seq=timeline5&orientation=landscape',
      icon: 'ri-group-line'
    },
    {
      year: '2024',
      title: 'AI Quality Control',
      description: 'Launched proprietary AI-powered defect detection system with 99.2% accuracy rate',
      image: 'https://readdy.ai/api/search-image?query=AI-powered%20textile%20quality%20control%20laboratory%20with%20advanced%20scanning%20technology%2C%20artificial%20intelligence%20defect%20detection%20systems%20analyzing%20fabric%20quality%2C%20high-tech%20textile%20inspection%20equipment%20with%20digital%20displays&width=600&height=400&seq=timeline6&orientation=landscape',
      icon: 'ri-cpu-line'
    }
  ];

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (scrollContainer) {
      const handleScroll = () => {
        const scrollLeft = scrollContainer.scrollLeft;
        const itemWidth = scrollContainer.scrollWidth / milestones.length;
        const newIndex = Math.round(scrollLeft / itemWidth);
        setSelectedMilestone(Math.min(newIndex, milestones.length - 1));
      };

      scrollContainer.addEventListener('scroll', handleScroll);
      return () => scrollContainer.removeEventListener('scroll', handleScroll);
    }
  }, [milestones.length]);

  const scrollToMilestone = (index) => {
    const scrollContainer = scrollContainerRef.current;
    if (scrollContainer) {
      const itemWidth = scrollContainer.scrollWidth / milestones.length;
      scrollContainer.scrollTo({
        left: index * itemWidth,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our Journey Through Time
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Three decades of innovation, growth, and commitment to textile excellence
          </p>
        </div>

        <div className="max-w-7xl mx-auto">
          <div 
            ref={scrollContainerRef}
            className="flex overflow-x-auto scrollbar-hide gap-8 pb-4 snap-x snap-mandatory"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {milestones.map((milestone, index) => (
              <div 
                key={index}
                className={`flex-none w-80 snap-center transition-all duration-300 ${
                  selectedMilestone === index ? 'transform scale-105' : ''
                }`}
              >
                <div className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 transition-all duration-300 hover:shadow-2xl cursor-pointer ${
                  selectedMilestone === index ? 'border-blue-500 shadow-xl' : 'border-transparent hover:border-blue-200'
                }`}
                onClick={() => scrollToMilestone(index)}
                >
                  <div className="relative">
                    <img 
                      src={milestone.image}
                      alt={milestone.title}
                      className="w-full h-48 object-cover object-top"
                    />
                    <div className="absolute top-4 left-4 bg-blue-600 text-white px-4 py-2 rounded-full font-bold">
                      {milestone.year}
                    </div>
                    <div className="absolute bottom-4 right-4 w-12 h-12 flex items-center justify-center bg-white/90 backdrop-blur-sm rounded-full">
                      <i className={`${milestone.icon} text-xl text-blue-700`}></i>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-3">
                      {milestone.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {milestone.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center mt-8 space-x-2">
            {milestones.map((_, index) => (
              <button
                key={index}
                onClick={() => scrollToMilestone(index)}
                className={`w-3 h-3 rounded-full transition-all cursor-pointer ${
                  selectedMilestone === index ? 'bg-blue-600' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}