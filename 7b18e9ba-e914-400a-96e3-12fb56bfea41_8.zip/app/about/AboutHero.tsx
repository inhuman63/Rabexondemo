'use client';

export default function AboutHero() {
  return (
    <section 
      className="relative min-h-screen flex items-center bg-cover bg-center"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Master%20textile%20weavers%20working%20with%20precision%20on%20advanced%20industrial%20looms%20in%20modern%20factory%2C%20skilled%20craftsmen%20operating%20high-tech%20weaving%20machinery%2C%20professional%20textile%20manufacturing%20environment%20with%20clean%20industrial%20aesthetic%2C%20workers%20in%20safety%20gear%20demonstrating%20expertise%20and%20craftsmanship%2C%20slow-motion%20quality%20workmanship%20scene&width=1920&height=1080&seq=abouthero1&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/95 via-blue-800/80 to-transparent"></div>
      
      <div className="relative z-10 mx-auto px-6 w-full">
        <div className="max-w-4xl">
          <div className="mb-8">
            <div className="inline-flex items-center bg-white/10 backdrop-blur-sm px-6 py-3 rounded-full border border-white/30 mb-6">
              <div className="w-3 h-3 bg-green-400 rounded-full mr-3 animate-pulse"></div>
              <span className="text-white font-medium">Trusted by 200+ Global Brands</span>
            </div>
          </div>
          
          <h1 className="text-6xl md:text-7xl font-bold text-white leading-tight mb-8">
            Precision Textiles,<br />
            <span className="text-blue-300">Global Trust</span><br />
            <span className="text-4xl md:text-5xl text-blue-100">Since 1992</span>
          </h1>
          
          <p className="text-2xl text-blue-100 mb-8 font-medium leading-relaxed max-w-3xl">
            Supplying premium fabrics across 45 countries with OEKO-TEX® certification and 30+ years of textile mastery
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/30">
              <div className="text-3xl font-bold text-white mb-2">98.7%</div>
              <div className="text-blue-100 text-sm font-medium">Defect-Free Rate</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/30">
              <div className="text-3xl font-bold text-white mb-2">45</div>
              <div className="text-blue-100 text-sm font-medium">Countries Served</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/30">
              <div className="text-3xl font-bold text-white mb-2">200+</div>
              <div className="text-blue-100 text-sm font-medium">Brand Partners</div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-700 transition-all transform hover:scale-105 shadow-lg whitespace-nowrap cursor-pointer">
              View Our Story
            </button>
            <button className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white/20 transition-all border border-white/30 whitespace-nowrap cursor-pointer">
              Meet the Team
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}