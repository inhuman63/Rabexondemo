'use client';

import { useState } from 'react';

export default function CertificationGallery() {
  const [selectedCert, setSelectedCert] = useState(null);

  const certifications = [
    {
      name: 'OEKO-TEX Standard 100',
      description: 'Textile products tested for harmful substances',
      issuer: 'International OEKO-TEX Association',
      validUntil: 'Dec 2025',
      scope: 'All fabric products and raw materials',
      verification: 'Certificate #2024-OK-15623',
      logo: 'https://readdy.ai/api/search-image?query=OEKO-TEX%20Standard%20100%20certification%20logo%20and%20badge%2C%20textile%20safety%20certification%20emblem%2C%20international%20textile%20standard%20symbol&width=150&height=100&seq=oeko1&orientation=landscape',
      benefits: ['No harmful chemicals', 'Skin-friendly textiles', 'Environmental safety']
    },
    {
      name: 'Global Organic Textile Standard',
      description: 'Leading standard for organic textile processing',
      issuer: 'Global Standard gGmbH',
      validUntil: 'Mar 2026',
      scope: 'Organic cotton and natural fiber products',
      verification: 'License #GOTS-2024-7891',
      logo: 'https://readdy.ai/api/search-image?query=GOTS%20Global%20Organic%20Textile%20Standard%20certification%20logo%2C%20organic%20textile%20certification%20badge%2C%20sustainable%20textile%20standard%20emblem&width=150&height=100&seq=gots1&orientation=landscape',
      benefits: ['Organic fiber content', 'Environmental criteria', 'Social criteria compliance']
    },
    {
      name: 'ISO 9001:2015',
      description: 'Quality management systems standard',
      issuer: 'International Organization for Standardization',
      validUntil: 'Jan 2027',
      scope: 'Complete manufacturing and quality processes',
      verification: 'Certificate #ISO-9001-2024-RBX',
      logo: 'https://readdy.ai/api/search-image?query=ISO%209001%202015%20certification%20logo%2C%20quality%20management%20system%20badge%2C%20international%20quality%20standard%20emblem&width=150&height=100&seq=iso1&orientation=landscape',
      benefits: ['Quality management', 'Continuous improvement', 'Customer satisfaction']
    },
    {
      name: 'Bluesign Approved',
      description: 'Sustainable textile production system',
      issuer: 'Bluesign Technologies AG',
      validUntil: 'Sep 2025',
      scope: 'Chemical management and worker safety',
      verification: 'Approval #BLUE-2024-3456',
      logo: 'https://readdy.ai/api/search-image?query=Bluesign%20approved%20certification%20logo%2C%20sustainable%20textile%20production%20badge%2C%20chemical%20safety%20standard%20emblem&width=150&height=100&seq=blue1&orientation=landscape',
      benefits: ['Chemical safety', 'Worker protection', 'Environmental responsibility']
    },
    {
      name: 'WRAP Certification',
      description: 'Worldwide Responsible Accredited Production',
      issuer: 'Worldwide Responsible Accredited Production',
      validUntil: 'Jun 2026',
      scope: 'Social compliance and workplace standards',
      verification: 'Certificate #WRAP-2024-8912',
      logo: 'https://readdy.ai/api/search-image?query=WRAP%20certification%20logo%2C%20workplace%20responsibility%20accreditation%20badge%2C%20social%20compliance%20standard%20emblem&width=150&height=100&seq=wrap1&orientation=landscape',
      benefits: ['Fair labor practices', 'Safe working conditions', 'Social accountability']
    },
    {
      name: 'ISO 14001:2015',
      description: 'Environmental management systems',
      issuer: 'International Organization for Standardization',
      validUntil: 'Nov 2026',
      scope: 'Environmental impact and sustainability',
      verification: 'Certificate #ISO-14001-2024-RBX',
      logo: 'https://readdy.ai/api/search-image?query=ISO%2014001%202015%20certification%20logo%2C%20environmental%20management%20system%20badge%2C%20sustainability%20standard%20emblem&width=150&height=100&seq=iso14001&orientation=landscape',
      benefits: ['Environmental management', 'Pollution prevention', 'Resource efficiency']
    }
  ];

  const openModal = (cert) => {
    setSelectedCert(cert);
  };

  const closeModal = () => {
    setSelectedCert(null);
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Global Certifications & Standards
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our commitment to quality, safety, and sustainability is validated by internationally recognized certifications
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {certifications.map((cert, index) => (
            <div 
              key={index} 
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
              onClick={() => openModal(cert)}
            >
              <div className="flex items-center justify-center mb-6">
                <img 
                  src={cert.logo}
                  alt={cert.name}
                  className="h-16 w-auto object-contain"
                />
              </div>
              
              <h3 className="text-lg font-bold text-gray-900 mb-3 text-center">
                {cert.name}
              </h3>
              
              <p className="text-gray-600 text-sm mb-4 text-center leading-relaxed">
                {cert.description}
              </p>
              
              <div className="space-y-2 text-xs text-gray-500">
                <div className="flex justify-between">
                  <span>Valid Until:</span>
                  <span className="font-semibold">{cert.validUntil}</span>
                </div>
                <div className="flex justify-between">
                  <span>Issuer:</span>
                  <span className="font-semibold truncate ml-2">{cert.issuer}</span>
                </div>
              </div>
              
              <div className="mt-4 text-center">
                <button className="text-blue-600 font-semibold text-sm hover:text-blue-700 transition-colors cursor-pointer">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <div className="bg-white rounded-2xl p-8 shadow-lg max-w-2xl mx-auto">
            <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mx-auto mb-6">
              <i className="ri-shield-check-line text-2xl text-green-700"></i>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              100% Certified Operations
            </h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              All our facilities maintain active certifications with regular third-party audits to ensure compliance with international standards.
            </p>
            <button className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
              Request Audit Report
            </button>
          </div>
        </div>
      </div>

      {selectedCert && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-2xl font-bold text-gray-900">
                {selectedCert.name}
              </h3>
              <button 
                onClick={closeModal}
                className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>

            <div className="flex items-center justify-center mb-8">
              <img 
                src={selectedCert.logo}
                alt={selectedCert.name}
                className="h-24 w-auto object-contain"
              />
            </div>

            <div className="space-y-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Description</h4>
                <p className="text-gray-600">{selectedCert.description}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Certification Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Issuer:</span>
                      <span className="font-medium">{selectedCert.issuer}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Valid Until:</span>
                      <span className="font-medium">{selectedCert.validUntil}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Verification:</span>
                      <span className="font-medium">{selectedCert.verification}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Key Benefits</h4>
                  <ul className="space-y-1">
                    {selectedCert.benefits.map((benefit, i) => (
                      <li key={i} className="text-sm text-gray-600 flex items-start">
                        <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 mr-2 flex-shrink-0"></div>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Scope of Certification</h4>
                <p className="text-gray-600 text-sm">{selectedCert.scope}</p>
              </div>
            </div>

            <div className="mt-8 flex justify-center">
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
                Download Certificate
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}