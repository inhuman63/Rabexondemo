'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AboutHero from './AboutHero';
import CompanyTimeline from './CompanyTimeline';
import LeadershipTeam from './LeadershipTeam';
import ClientProof from './ClientProof';
import TrustMetrics from './TrustMetrics';
import CertificationGallery from './CertificationGallery';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <AboutHero />
      <TrustMetrics />
      <CompanyTimeline />
      <LeadershipTeam />
      <ClientProof />
      <CertificationGallery />
      <Footer />
    </div>
  );
}