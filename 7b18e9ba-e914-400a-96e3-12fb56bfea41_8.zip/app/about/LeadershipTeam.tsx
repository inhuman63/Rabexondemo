'use client';

import { useState } from 'react';

export default function LeadershipTeam() {
  const [selectedMember, setSelectedMember] = useState(null);

  const leadership = [
    {
      name: 'Hiroshi Tanaka',
      title: 'Founder & CEO',
      bio: 'Started with 3 looms in 1992, now oversees 12 smart factories across Asia. Pioneered sustainable textile manufacturing practices.',
      experience: '30+ years',
      specialization: 'Strategic Vision & Operations',
      achievements: ['Founded company in 1992', 'Expanded to 45 countries', '200+ brand partnerships'],
      image: 'https://readdy.ai/api/search-image?query=Professional%20Japanese%20business%20executive%20CEO%20in%20modern%20office%20setting%2C%20distinguished%20senior%20textile%20industry%20leader%2C%20confident%20business%20founder%20in%20elegant%20suit%2C%20corporate%20leadership%20portrait%20with%20textile%20manufacturing%20background&width=300&height=400&seq=ceo1&orientation=portrait',
      signature: true
    },
    {
      name: 'Dr. Sarah Chen',
      title: 'Chief Technology Officer',
      bio: 'PhD in Materials Science from MIT. Leads our AI-powered quality control initiatives and sustainable innovation projects.',
      experience: '15+ years',
      specialization: 'AI & Materials Science',
      achievements: ['Patent #US202415623A1 - AI Defect Detection', 'Led Smart Factory Initiative', '99.2% accuracy rate achievement'],
      image: 'https://readdy.ai/api/search-image?query=Professional%20Asian%20female%20technology%20executive%20in%20modern%20laboratory%2C%20PhD%20scientist%20in%20materials%20science%2C%20confident%20tech%20leader%20examining%20textile%20samples%2C%20professional%20corporate%20portrait%20with%20high-tech%20background&width=300&height=400&seq=cto1&orientation=portrait',
      signature: false
    },
    {
      name: 'Marcus Rodriguez',
      title: 'VP Global Operations',
      bio: 'Former logistics director at Fortune 500 company. Ensures our 98% on-time delivery rate across 45 countries.',
      experience: '20+ years',
      specialization: 'Global Logistics & Supply Chain',
      achievements: ['98% on-time delivery rate', 'Global supply chain optimization', '45-country distribution network'],
      image: 'https://readdy.ai/api/search-image?query=Professional%20Hispanic%20business%20executive%20in%20logistics%20operations%20center%2C%20confident%20VP%20of%20global%20operations%2C%20supply%20chain%20management%20expert%2C%20corporate%20leader%20with%20international%20shipping%20background&width=300&height=400&seq=vp1&orientation=portrait',
      signature: false
    },
    {
      name: 'Elena Kowalski',
      title: 'Head of Quality Assurance',
      bio: 'OEKO-TEX certified inspector with expertise in international textile standards and sustainable manufacturing practices.',
      experience: '18+ years',
      specialization: 'Quality Control & Certification',
      achievements: ['OEKO-TEX certification leadership', '98.7% defect-free rate', 'International standards compliance'],
      image: 'https://readdy.ai/api/search-image?query=Professional%20female%20quality%20assurance%20manager%20in%20textile%20inspection%20laboratory%2C%20confident%20quality%20control%20expert%20examining%20fabric%20samples%2C%20textile%20certification%20specialist%20in%20professional%20setting&width=300&height=400&seq=qa1&orientation=portrait',
      signature: false
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Leadership Excellence
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Meet the visionary leaders driving innovation and excellence in textile manufacturing
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {leadership.map((member, index) => (
            <div key={index} className="relative group">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer"
                   onClick={() => setSelectedMember(selectedMember === index ? null : index)}>
                <div className="relative">
                  <img 
                    src={member.image}
                    alt={member.name}
                    className="w-full h-80 object-cover object-top"
                  />
                  {member.signature && (
                    <div className="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-bold">
                      Founder
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">
                    {member.name}
                  </h3>
                  <p className="text-blue-600 font-semibold mb-3">
                    {member.title}
                  </p>
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center">
                      <div className="w-4 h-4 flex items-center justify-center mr-2">
                        <i className="ri-time-line"></i>
                      </div>
                      {member.experience}
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">
                    {member.bio}
                  </p>
                  <button className="mt-4 text-blue-600 font-semibold text-sm hover:text-blue-700 transition-colors cursor-pointer">
                    {selectedMember === index ? 'Show Less' : 'Learn More'}
                  </button>
                </div>
              </div>

              {selectedMember === index && (
                <div className="absolute top-full left-0 right-0 z-20 mt-4 bg-white rounded-2xl shadow-2xl p-6 border border-gray-200">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Specialization</h4>
                      <p className="text-gray-600 text-sm">{member.specialization}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Key Achievements</h4>
                      <ul className="space-y-1">
                        {member.achievements.map((achievement, i) => (
                          <li key={i} className="text-gray-600 text-sm flex items-start">
                            <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 mr-2 flex-shrink-0"></div>
                            {achievement}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="bg-blue-50 rounded-2xl p-8 max-w-2xl mx-auto">
            <div className="w-16 h-16 flex items-center justify-center bg-blue-100 rounded-full mx-auto mb-6">
              <i className="ri-team-line text-2xl text-blue-700"></i>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Join Our Team
            </h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              We're always looking for talented individuals who share our passion for textile excellence and innovation.
            </p>
            <button className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
              View Open Positions
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}