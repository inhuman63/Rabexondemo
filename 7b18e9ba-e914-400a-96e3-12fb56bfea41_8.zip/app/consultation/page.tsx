
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ConsultationHero from './ConsultationHero';
import BookingSystem from './BookingSystem';
import ConsultationBenefits from './ConsultationBenefits';

export default function ConsultationPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <ConsultationHero />
      <ConsultationBenefits />
      <BookingSystem />
      <Footer />
    </div>
  );
}
