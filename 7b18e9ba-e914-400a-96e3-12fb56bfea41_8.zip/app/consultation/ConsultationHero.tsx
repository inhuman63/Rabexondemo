
'use client';

export default function ConsultationHero() {
  return (
    <section 
      className="relative py-32 bg-cover bg-center"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Professional%20business%20consultation%20meeting%20with%20textile%20experts%20and%20clients%20in%20modern%20conference%20room%2C%20business%20professionals%20discussing%20fabric%20samples%20and%20technical%20specifications%2C%20corporate%20consultation%20environment%20with%20fabric%20swatches%20and%20documentation&width=1920&height=800&seq=conshero1&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-blue-900/60"></div>
      
      <div className="relative z-10 mx-auto px-6 text-center">
        <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
          Expert Textile Consultation
        </h1>
        <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto leading-relaxed">
          Get personalized guidance from our textile specialists. Book a consultation to discuss your specific requirements and discover the perfect fabric solutions.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/30">
            <div className="w-12 h-12 flex items-center justify-center bg-white/20 rounded-full mx-auto mb-4">
              <i className="ri-user-line text-2xl text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Expert Guidance</h3>
            <p className="text-blue-100 text-sm">29+ years of textile industry experience</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/30">
            <div className="w-12 h-12 flex items-center justify-center bg-white/20 rounded-full mx-auto mb-4">
              <i className="ri-time-line text-2xl text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Quick Response</h3>
            <p className="text-blue-100 text-sm">Same-day booking confirmation</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/30">
            <div className="w-12 h-12 flex items-center justify-center bg-white/20 rounded-full mx-auto mb-4">
              <i className="ri-settings-line text-2xl text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Custom Solutions</h3>
            <p className="text-blue-100 text-sm">Tailored recommendations for your needs</p>
          </div>
        </div>
      </div>
    </section>
  );
}
