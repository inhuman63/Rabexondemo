
'use client';

export default function ConsultationBenefits() {
  const benefits = [
    {
      icon: 'ri-search-line',
      title: 'Fabric Selection Guidance',
      description: 'Expert recommendations based on your specific application requirements, budget, and quality standards.',
      features: ['Material properties analysis', 'Cost optimization', 'Quality standards matching']
    },
    {
      icon: 'ri-calculator-line',
      title: 'Instant Quote Generation',
      description: 'AI-powered pricing tool that provides accurate quotes based on specifications, quantity, and delivery timeline.',
      features: ['Real-time pricing', 'Volume discounts', 'Delivery cost calculation']
    },
    {
      icon: 'ri-truck-line',
      title: 'Supply Chain Planning',
      description: 'Complete logistics support with blockchain-based tracking and optimized delivery scheduling.',
      features: ['Production timeline', 'Shipping coordination', 'Quality checkpoints']
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Quality Assurance',
      description: 'Comprehensive quality control processes with certification compliance and testing protocols.',
      features: ['Pre-shipment testing', 'Certification verification', 'Quality documentation']
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Comprehensive Consultation Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our expert team provides end-to-end support for all your textile sourcing needs
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {benefits.map((benefit, index) => (
            <div key={index} className="bg-white p-8 rounded-lg shadow-lg">
              <div className="flex items-start space-x-4">
                <div className="w-16 h-16 flex items-center justify-center bg-blue-100 rounded-full flex-shrink-0">
                  <i className={`${benefit.icon} text-2xl text-blue-700`}></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">
                    {benefit.title}
                  </h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    {benefit.description}
                  </p>
                  <ul className="space-y-2">
                    {benefit.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-gray-700">
                        <div className="w-4 h-4 flex items-center justify-center mr-3">
                          <i className="ri-check-line text-green-600"></i>
                        </div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
