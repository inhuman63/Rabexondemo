
'use client';

import Link from 'next/link';

export default function CTA() {
  return (
    <section 
      className="py-20 bg-cover bg-center relative"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Professional%20textile%20manufacturing%20consultation%20meeting%20with%20business%20professionals%20discussing%20fabric%20samples%2C%20modern%20conference%20room%20setting%20with%20textile%20experts%20and%20clients%20reviewing%20quality%20materials%2C%20corporate%20business%20environment%20with%20fabric%20swatches%20and%20technical%20documentation&width=1920&height=600&seq=cta1&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-blue-900/85"></div>
      
      <div className="relative z-10 mx-auto px-6 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
          Ready to Transform Your Textile Sourcing?
        </h2>
        <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto leading-relaxed">
          Join over 150 global clients who trust Rabexon for premium textile solutions. Get started with a personalized consultation today.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/consultation" className="bg-blue-600 text-white px-10 py-4 rounded-lg font-semibold text-lg hover:bg-blue-700 transition-all transform hover:scale-105 shadow-lg whitespace-nowrap cursor-pointer">
            Schedule Consultation
          </Link>
          <Link href="/products" className="bg-white/10 backdrop-blur-sm text-white px-10 py-4 rounded-lg font-semibold text-lg hover:bg-white/20 transition-all border border-white/30 whitespace-nowrap cursor-pointer">
            Explore Products
          </Link>
        </div>
        
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="w-16 h-16 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-full mx-auto mb-4">
              <i className="ri-phone-line text-2xl text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Instant Response</h3>
            <p className="text-blue-100 text-sm">Get quotes within 24 hours</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-full mx-auto mb-4">
              <i className="ri-shield-check-line text-2xl text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Quality Guaranteed</h3>
            <p className="text-blue-100 text-sm">100% satisfaction guarantee</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-full mx-auto mb-4">
              <i className="ri-global-line text-2xl text-white"></i>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Global Delivery</h3>
            <p className="text-blue-100 text-sm">Worldwide shipping available</p>
          </div>
        </div>
      </div>
    </section>
  );
}
