
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Hero from './Hero';
import Features from './Features';
import Products from './Products';
import Stats from './Stats';
import CTA from './CTA';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <Stats />
      <Features />
      <Products />
      <CTA />
      <Footer />
    </div>
  );
}
