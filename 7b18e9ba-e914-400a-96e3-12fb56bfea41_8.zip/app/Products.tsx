
'use client';

import Link from 'next/link';

export default function Products() {
  const products = [
    {
      name: 'Premium Cotton',
      category: 'Fashion Textiles',
      specs: {
        threadCount: '144×72',
        composition: '98% Cotton, 2% Spandex',
        weight: '210 GSM',
        certifications: 'OEKO-TEX®, GOTS'
      },
      minOrder: '500m',
      leadTime: '4-6 weeks',
      image: 'https://readdy.ai/api/search-image?query=Premium%20cotton%20fabric%20texture%20close-up%20showing%20fine%20weave%20quality%2C%20natural%20cotton%20textile%20with%20soft%20texture%20and%20professional%20lighting%2C%20high-quality%20cotton%20material%20for%20fashion%20industry%2C%20clean%20white%20background%20highlighting%20fabric%20detail&width=400&height=300&seq=prod1&orientation=landscape'
    },
    {
      name: 'Athletic Performance',
      category: 'Sportswear',
      specs: {
        threadCount: '180×96',
        composition: '92% Polyester, 8% Elastane',
        weight: '185 GSM',
        certifications: 'STANDARD 100, Bluesign®'
      },
      minOrder: '300m',
      leadTime: '3-5 weeks',
      image: 'https://readdy.ai/api/search-image?query=Athletic%20performance%20fabric%20for%20sportswear%20showing%20moisture-wicking%20textile%2C%20technical%20sports%20fabric%20with%20stretch%20properties%2C%20high-performance%20athletic%20material%20for%20fitness%20apparel%2C%20modern%20sports%20textile%20technology&width=400&height=300&seq=prod2&orientation=landscape'
    },
    {
      name: 'Medical Grade',
      category: 'Medical Textiles',
      specs: {
        threadCount: '200×120',
        composition: '100% Antimicrobial Polyester',
        weight: '150 GSM',
        certifications: 'ISO 13485, FDA Approved'
      },
      minOrder: '200m',
      leadTime: '2-4 weeks',
      image: 'https://readdy.ai/api/search-image?query=Medical%20grade%20textile%20fabric%20for%20healthcare%20applications%2C%20antimicrobial%20fabric%20with%20sterile%20properties%2C%20professional%20medical%20textile%20material%2C%20clean%20healthcare%20fabric%20with%20technical%20specifications&width=400&height=300&seq=prod3&orientation=landscape'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Featured Product Categories
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our comprehensive range of premium textiles designed for various industries and applications.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {products.map((product, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover object-top"
              />
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-xl font-bold text-gray-900">{product.name}</h3>
                  <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    {product.category}
                  </span>
                </div>
                
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Thread Count:</span>
                    <span className="font-medium">{product.specs.threadCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Composition:</span>
                    <span className="font-medium">{product.specs.composition}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Weight:</span>
                    <span className="font-medium">{product.specs.weight}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Certifications:</span>
                    <span className="font-medium">{product.specs.certifications}</span>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <div className="text-sm text-gray-600">Min. Order</div>
                      <div className="font-semibold">{product.minOrder}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600">Lead Time</div>
                      <div className="font-semibold">{product.leadTime}</div>
                    </div>
                  </div>
                  
                  <Link href="/products" className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors block text-center whitespace-nowrap cursor-pointer">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link href="/products" className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold border-2 border-blue-600 hover:bg-blue-600 hover:text-white transition-colors whitespace-nowrap cursor-pointer">
            View All Products
          </Link>
        </div>
      </div>
    </section>
  );
}
