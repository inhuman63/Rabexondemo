
'use client';

import { useState, useEffect } from 'react';

export default function DashboardOverview({ onNewOrder, onDownloadReports }) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const getWelcomeMessage = () => {
    const hour = currentTime.getHours();
    const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
    return `${greeting}, TextileCorp Procurement Team`;
  };

  const stats = [
    {
      title: 'Open Orders',
      value: '12',
      change: '+5%',
      trend: 'up',
      icon: 'ri-shopping-bag-line',
      color: 'blue'
    },
    {
      title: 'Pending Samples',
      value: '3',
      change: '-2',
      trend: 'down',
      icon: 'ri-flask-line',
      color: 'orange'
    },
    {
      title: 'Credit Utilization',
      value: '$85,000',
      total: '$100,000',
      percentage: 85,
      icon: 'ri-credit-card-line',
      color: 'green'
    },
    {
      title: 'This Month Orders',
      value: '$45,280',
      change: '+18%',
      trend: 'up',
      icon: 'ri-line-chart-line',
      color: 'purple'
    }
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'order',
      message: 'Order TX-4893 has been shipped',
      time: '2 hours ago',
      icon: 'ri-truck-line',
      color: 'green'
    },
    {
      id: 2,
      type: 'sample',
      message: 'Sample request approved for Organic Cotton Twill',
      time: '5 hours ago',
      icon: 'ri-check-line',
      color: 'blue'
    },
    {
      id: 3,
      type: 'document',
      message: 'New invoice uploaded for order TX-4891',
      time: '1 day ago',
      icon: 'ri-file-text-line',
      color: 'gray'
    },
    {
      id: 4,
      type: 'payment',
      message: 'Payment processed for $12,450',
      time: '2 days ago',
      icon: 'ri-secure-payment-line',
      color: 'green'
    }
  ];

  const upcomingDeliveries = [
    {
      order: 'TX-4892',
      fabric: 'Organic Cotton Canvas',
      quantity: '4,500m',
      estimatedDate: '2024-06-15',
      status: 'In Transit'
    },
    {
      order: 'TX-4890',
      fabric: 'Athletic Performance Mesh',
      quantity: '2,800m',
      estimatedDate: '2024-06-18',
      status: 'Production'
    },
    {
      order: 'TX-4889',
      fabric: 'Medical Grade Antimicrobial',
      quantity: '1,200m',
      estimatedDate: '2024-06-22',
      status: 'Quality Check'
    }
  ];

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2" suppressHydrationWarning={true}>
              {getWelcomeMessage()}
            </h2>
            <p className="text-blue-100">
              Here's an overview of your current orders and account status
            </p>
          </div>
          <div className="w-16 h-16 flex items-center justify-center bg-blue-500 rounded-full">
            <i className="ri-user-line text-2xl"></i>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white border border-gray-200 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 flex items-center justify-center bg-${stat.color}-100 rounded-lg`}>
                <i className={`${stat.icon} text-${stat.color}-600 text-xl`}></i>
              </div>
              {stat.change && (
                <span className={`flex items-center text-sm font-medium ${stat.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                  <i className={`${stat.trend === 'up' ? 'ri-arrow-up-line' : 'ri-arrow-down-line'} mr-1`}></i>
                  {stat.change}
                </span>
              )}
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-1">
              {stat.value}
              {stat.total && <span className="text-lg text-gray-500">/{stat.total}</span>}
            </h3>
            <p className="text-gray-600 text-sm">{stat.title}</p>
            {stat.percentage && (
              <div className="mt-3">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Credit Used</span>
                  <span>{stat.percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`bg-${stat.color}-600 h-2 rounded-full`}
                    style={{ width: `${stat.percentage}%` }}
                  ></div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3">
                <div className={`w-8 h-8 flex items-center justify-center bg-${activity.color}-100 rounded-full flex-shrink-0`}>
                  <i className={`${activity.icon} text-${activity.color}-600 text-sm`}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Upcoming Deliveries</h3>
          <div className="space-y-4">
            {upcomingDeliveries.map((delivery, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <div className="font-semibold text-gray-900">{delivery.order}</div>
                  <div className="text-sm text-gray-600">{delivery.fabric}</div>
                  <div className="text-sm text-gray-500">{delivery.quantity}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-gray-900">{delivery.estimatedDate}</div>
                  <span className={`inline-block px-2 py-1 text-xs rounded-full ${delivery.status === 'In Transit' ? 'bg-blue-100 text-blue-800' : delivery.status === 'Production' ? 'bg-orange-100 text-orange-800' : 'bg-yellow-100 text-yellow-800'}`}>
                    {delivery.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-gray-900">Quick Actions</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <button 
            onClick={onNewOrder}
            className="flex items-center justify-center space-x-2 p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-add-line text-blue-600"></i>
            </div>
            <span className="font-medium text-blue-600 whitespace-nowrap">New Order</span>
          </button>
          <button className="flex items-center justify-center space-x-2 p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors cursor-pointer">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-flask-line text-green-600"></i>
            </div>
            <span className="font-medium text-green-600 whitespace-nowrap">Request Sample</span>
          </button>
          <button className="flex items-center justify-center space-x-2 p-4 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors cursor-pointer">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-customer-service-line text-orange-600"></i>
            </div>
            <span className="font-medium text-orange-600 whitespace-nowrap">Support</span>
          </button>
          <button 
            onClick={onDownloadReports}
            className="flex items-center justify-center space-x-2 p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-file-download-line text-purple-600"></i>
            </div>
            <span className="font-medium text-purple-600 whitespace-nowrap">Download Reports</span>
          </button>
        </div>
      </div>
    </div>
  );
}
