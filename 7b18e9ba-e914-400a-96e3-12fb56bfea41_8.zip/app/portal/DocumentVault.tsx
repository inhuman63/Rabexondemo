'use client';

import { useState } from 'react';

export default function DocumentVault() {
  const [activeFolder, setActiveFolder] = useState('all');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  const folders = [
    { id: 'all', name: 'All Documents', count: 45, icon: 'ri-folder-line' },
    { id: 'contracts', name: 'Contracts', count: 12, icon: 'ri-file-text-line' },
    { id: 'certificates', name: 'Certificates', count: 8, icon: 'ri-award-line' },
    { id: 'invoices', name: 'Invoices', count: 18, icon: 'ri-bill-line' },
    { id: 'samples', name: 'Sample Reports', count: 7, icon: 'ri-flask-line' }
  ];

  const documents = [
    {
      id: 1,
      name: 'Master Supply Agreement 2024.pdf',
      type: 'contracts',
      size: '2.4 MB',
      uploadDate: '2024-01-15',
      status: 'active',
      icon: 'ri-file-pdf-line',
      color: 'red'
    },
    {
      id: 2,
      name: 'OEKO-TEX Certificate - Organic Cotton.pdf',
      type: 'certificates',
      size: '1.8 MB',
      uploadDate: '2024-02-10',
      status: 'active',
      icon: 'ri-file-pdf-line',
      color: 'red'
    },
    {
      id: 3,
      name: 'Invoice TX-4892.pdf',
      type: 'invoices',
      size: '652 KB',
      uploadDate: '2024-05-20',
      status: 'pending',
      icon: 'ri-file-pdf-line',
      color: 'red'
    },
    {
      id: 4,
      name: 'GOTS Certificate - Athletic Mesh.pdf',
      type: 'certificates',
      size: '1.2 MB',
      uploadDate: '2024-03-08',
      status: 'active',
      icon: 'ri-file-pdf-line',
      color: 'red'
    },
    {
      id: 5,
      name: 'Quality Report - Medical Antimicrobial.xlsx',
      type: 'samples',
      size: '890 KB',
      uploadDate: '2024-04-15',
      status: 'active',
      icon: 'ri-file-excel-line',
      color: 'green'
    },
    {
      id: 6,
      name: 'Batch Test Results - Cotton Canvas.pdf',
      type: 'samples',
      size: '3.1 MB',
      uploadDate: '2024-05-01',
      status: 'active',
      icon: 'ri-file-pdf-line',
      color: 'red'
    },
    {
      id: 7,
      name: 'Payment Terms Amendment.docx',
      type: 'contracts',
      size: '145 KB',
      uploadDate: '2024-05-18',
      status: 'draft',
      icon: 'ri-file-word-line',
      color: 'blue'
    },
    {
      id: 8,
      name: 'ISO 13485 Certificate - Medical Textiles.pdf',
      type: 'certificates',
      size: '2.0 MB',
      uploadDate: '2024-02-25',
      status: 'active',
      icon: 'ri-file-pdf-line',
      color: 'red'
    }
  ];

  const filteredDocuments = activeFolder === 'all' 
    ? documents 
    : documents.filter(doc => doc.type === activeFolder);

  const handleFileUpload = (event) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      
      if (file.type !== 'application/pdf' && activeFolder === 'contracts') {
        alert('Only PDFs accepted for contracts');
        return;
      }

      setIsUploading(true);
      setUploadProgress(0);

      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsUploading(false);
            return 100;
          }
          return prev + 10;
        });
      }, 200);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'green';
      case 'pending': return 'yellow';
      case 'draft': return 'blue';
      default: return 'gray';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-900">Document Vault</h2>
        <div className="flex items-center space-x-4">
          <input
            type="file"
            id="file-upload"
            className="hidden"
            onChange={handleFileUpload}
            accept=".pdf,.doc,.docx,.xlsx,.xls"
          />
          <label 
            htmlFor="file-upload"
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer"
          >
            <div className="w-4 h-4 flex items-center justify-center">
              <i className="ri-upload-line"></i>
            </div>
            <span className="whitespace-nowrap">Upload Document</span>
          </label>
        </div>
      </div>

      {isUploading && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-blue-800">Uploading document...</span>
            <span className="text-sm text-blue-600">{uploadProgress}%</span>
          </div>
          <div className="w-full bg-blue-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${uploadProgress}%` }}
            ></div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-4">Folders</h3>
            <div className="space-y-2">
              {folders.map((folder) => (
                <button
                  key={folder.id}
                  onClick={() => setActiveFolder(folder.id)}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg text-left transition-colors cursor-pointer ${
                    activeFolder === folder.id
                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="w-5 h-5 flex items-center justify-center">
                    <i className={folder.icon}></i>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{folder.name}</div>
                    <div className="text-sm text-gray-500">{folder.count} files</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-3">
          <div className="bg-white border border-gray-200 rounded-lg">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">
                  {folders.find(f => f.id === activeFolder)?.name || 'Documents'}
                </h3>
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-gray-400 hover:text-gray-600 cursor-pointer">
                    <div className="w-5 h-5 flex items-center justify-center">
                      <i className="ri-list-unordered"></i>
                    </div>
                  </button>
                  <button className="p-2 text-gray-400 hover:text-gray-600 cursor-pointer">
                    <div className="w-5 h-5 flex items-center justify-center">
                      <i className="ri-grid-line"></i>
                    </div>
                  </button>
                </div>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 gap-4">
                {filteredDocuments.map((doc) => (
                  <div key={doc.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className={`w-10 h-10 flex items-center justify-center bg-${doc.color}-100 rounded-lg`}>
                      <i className={`${doc.icon} text-${doc.color}-600`}></i>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-gray-900 truncate">{doc.name}</div>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>{doc.size}</span>
                        <span>•</span>
                        <span>Uploaded {doc.uploadDate}</span>
                        <span>•</span>
                        <span className={`inline-flex px-2 py-1 text-xs rounded-full bg-${getStatusColor(doc.status)}-100 text-${getStatusColor(doc.status)}-800`}>
                          {doc.status}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors cursor-pointer">
                        <div className="w-5 h-5 flex items-center justify-center">
                          <i className="ri-eye-line"></i>
                        </div>
                      </button>
                      <button className="p-2 text-gray-400 hover:text-green-600 transition-colors cursor-pointer">
                        <div className="w-5 h-5 flex items-center justify-center">
                          <i className="ri-download-line"></i>
                        </div>
                      </button>
                      <button className="p-2 text-gray-400 hover:text-red-600 transition-colors cursor-pointer">
                        <div className="w-5 h-5 flex items-center justify-center">
                          <i className="ri-delete-bin-line"></i>
                        </div>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {filteredDocuments.length === 0 && (
                <div className="text-center py-12">
                  <div className="w-16 h-16 flex items-center justify-center bg-gray-100 rounded-full mx-auto mb-4">
                    <i className="ri-folder-line text-2xl text-gray-400"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No documents found</h3>
                  <p className="text-gray-500">Upload your first document to get started.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Storage Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">2.8 GB</div>
            <div className="text-sm text-gray-500">Used Storage</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-400">10 GB</div>
            <div className="text-sm text-gray-500">Total Storage</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">45</div>
            <div className="text-sm text-gray-500">Total Files</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">12</div>
            <div className="text-sm text-gray-500">Shared Files</div>
          </div>
        </div>
        
        <div className="mt-6">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Storage Usage</span>
            <span>28% used</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '28%' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
}