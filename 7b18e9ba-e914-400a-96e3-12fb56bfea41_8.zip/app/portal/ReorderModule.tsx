
'use client';

import { useState } from 'react';
import NewOrderForm from './NewOrderForm';

export default function ReorderModule() {
  const [selectedOrders, setSelectedOrders] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [showNewOrderForm, setShowNewOrderForm] = useState(false);

  const pastOrders = [
    {
      id: 'TX-4890',
      date: '2024-04-01',
      fabric: 'Medical Grade Antimicrobial',
      quantity: '800m',
      specifications: {
        threadCount: '200×120',
        weight: '150 GSM',
        composition: '100% Antimicrobial Polyester',
        color: 'Sterile White'
      },
      originalPrice: '$24.90/m',
      currentPrice: '$23.50/m',
      totalValue: '$19,920',
      newTotalValue: '$18,800',
      status: 'delivered',
      certifications: ['ISO 13485', 'FDA Approved'],
      inStock: true,
      leadTime: '2-4 weeks',
      promotion: '5% volume discount available'
    },
    {
      id: 'TX-4887',
      date: '2024-03-15',
      fabric: 'Premium Cotton Canvas',
      quantity: '1,200m',
      specifications: {
        threadCount: '144×72',
        weight: '210 GSM',
        composition: '98% Cotton, 2% Spandex',
        color: 'Natural Beige'
      },
      originalPrice: '$12.50/m',
      currentPrice: '$12.80/m',
      totalValue: '$15,000',
      newTotalValue: '$15,360',
      status: 'delivered',
      certifications: ['OEKO-TEX', 'GOTS'],
      inStock: true,
      leadTime: '4-6 weeks',
      promotion: null
    },
    {
      id: 'TX-4885',
      date: '2024-02-20',
      fabric: 'Athletic Performance Mesh',
      quantity: '650m',
      specifications: {
        threadCount: '180×96',
        weight: '185 GSM',
        composition: '92% Polyester, 8% Elastane',
        color: 'Deep Navy'
      },
      originalPrice: '$18.75/m',
      currentPrice: '$19.25/m',
      totalValue: '$12,187',
      newTotalValue: '$12,512',
      status: 'delivered',
      certifications: ['STANDARD 100', 'Bluesign'],
      inStock: false,
      leadTime: '6-8 weeks',
      promotion: 'New seasonal colors available'
    },
    {
      id: 'TX-4882',
      date: '2024-01-10',
      fabric: 'Organic Cotton Twill',
      quantity: '2,000m',
      specifications: {
        threadCount: '120×80',
        weight: '230 GSM',
        composition: '100% Organic Cotton',
        color: 'Khaki Brown'
      },
      originalPrice: '$14.20/m',
      currentPrice: '$13.90/m',
      totalValue: '$28,400',
      newTotalValue: '$27,800',
      status: 'delivered',
      certifications: ['GOTS', 'Organic Content'],
      inStock: true,
      leadTime: '3-5 weeks',
      promotion: 'Early bird 2% discount for Q3 orders'
    }
  ];

  const toggleOrderSelection = (orderId) => {
    setSelectedOrders(prev => 
      prev.includes(orderId) 
        ? prev.filter(id => id !== orderId)
        : [...prev, orderId]
    );
  };

  const handleOneClickReorder = (order) => {
    setSelectedOrders([order.id]);
    setShowCart(true);
  };

  const getSelectedOrdersData = () => {
    return pastOrders.filter(order => selectedOrders.includes(order.id));
  };

  const calculateTotal = () => {
    return getSelectedOrdersData().reduce((total, order) => {
      return total + parseFloat(order.newTotalValue.replace(/[$,]/g, ''));
    }, 0);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Reorder Center</h2>
          <p className="text-gray-600">Quickly reorder from your purchase history</p>
        </div>
        <div className="flex space-x-3">
          <button 
            onClick={() => setShowNewOrderForm(true)}
            className="flex items-center justify-center space-x-2 p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-add-line text-blue-600"></i>
            </div>
            <span className="font-medium text-blue-600 whitespace-nowrap">New Order</span>
          </button>
          {selectedOrders.length > 0 && (
            <button 
              onClick={() => setShowCart(true)}
              className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer"
            >
              <div className="w-5 h-5 flex items-center justify-center">
                <i className="ri-shopping-cart-line"></i>
              </div>
              <span className="whitespace-nowrap">Review Cart ({selectedOrders.length})</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {pastOrders.map((order) => (
          <div key={order.id} className={`bg-white border-2 rounded-xl p-6 transition-all ${ 
            selectedOrders.includes(order.id) ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
          }`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{order.fabric}</h3>
                <p className="text-sm text-gray-500">Order {order.id} • {order.date}</p>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={selectedOrders.includes(order.id)}
                  onChange={() => toggleOrderSelection(order.id)}
                  className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
              <div>
                <span className="text-gray-600">Quantity:</span>
                <div className="font-medium">{order.quantity}</div>
              </div>
              <div>
                <span className="text-gray-600">Lead Time:</span>
                <div className="font-medium">{order.leadTime}</div>
              </div>
              <div>
                <span className="text-gray-600">Thread Count:</span>
                <div className="font-medium">{order.specifications.threadCount}</div>
              </div>
              <div>
                <span className="text-gray-600">Weight:</span>
                <div className="font-medium">{order.specifications.weight}</div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Original Price:</span>
                <span className="text-sm text-gray-500 line-through">{order.originalPrice}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-900">Current Price:</span>
                <span className="text-lg font-bold text-blue-600">{order.currentPrice}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-900">Total Value:</span>
                <span className="text-lg font-bold text-gray-900">{order.newTotalValue}</span>
              </div>
              {parseFloat(order.newTotalValue.replace(/[$,]/g, '')) < parseFloat(order.totalValue.replace(/[$,]/g, '')) && (
                <div className="text-sm text-green-600 font-medium mt-1">
                  Save ${(parseFloat(order.totalValue.replace(/[$,]/g, '')) - parseFloat(order.newTotalValue.replace(/[$,]/g, ''))).toLocaleString()}
                </div>
              )}
            </div>

            {order.promotion && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
                <div className="flex items-center space-x-2">
                  <div className="w-5 h-5 flex items-center justify-center">
                    <i className="ri-gift-line text-yellow-600"></i>
                  </div>
                  <span className="text-sm font-medium text-yellow-800">{order.promotion}</span>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className={`flex items-center space-x-2 text-sm ${ 
                  order.inStock ? 'text-green-600' : 'text-orange-600'
                }`}>
                  <div className="w-4 h-4 flex items-center justify-center">
                    <i className={order.inStock ? 'ri-check-line' : 'ri-time-line'}></i>
                  </div>
                  <span>{order.inStock ? 'In Stock' : 'Extended Lead Time'}</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-1">
                {order.certifications.map((cert, index) => (
                  <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium">
                    {cert}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex space-x-3">
              <button 
                onClick={() => handleOneClickReorder(order)}
                className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer"
              >
                One-Click Reorder
              </button>
              <button className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer">
                Modify & Add
              </button>
            </div>
          </div>
        ))}
      </div>

      {showNewOrderForm && (
        <NewOrderForm onClose={() => setShowNewOrderForm(false)} />
      )}

      {showCart && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900">Review Reorder</h3>
                <button 
                  onClick={() => setShowCart(false)}
                  className="text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <div className="w-6 h-6 flex items-center justify-center">
                    <i className="ri-close-line"></i>
                  </div>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {getSelectedOrdersData().map((order) => (
                <div key={order.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{order.fabric}</h4>
                    <p className="text-sm text-gray-600">{order.quantity} • {order.currentPrice}</p>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-gray-900">{order.newTotalValue}</div>
                  </div>
                </div>
              ))}

              <div className="border-t border-gray-200 pt-4">
                <div className="flex justify-between items-center text-lg font-bold">
                  <span>Total:</span>
                  <span>${calculateTotal().toLocaleString()}</span>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-3">Order Options</h4>
                <div className="space-y-2">
                  <label className="flex items-center space-x-3">
                    <input type="checkbox" defaultChecked className="text-blue-600 border-gray-300 rounded" />
                    <span className="text-sm">Apply current promotions</span>
                  </label>
                  <label className="flex items-center space-x-3">
                    <input type="checkbox" defaultChecked className="text-blue-600 border-gray-300 rounded" />
                    <span className="text-sm">Request quality samples</span>
                  </label>
                  <label className="flex items-center space-x-3">
                    <input type="checkbox" className="text-blue-600 border-gray-300 rounded" />
                    <span className="text-sm">Rush delivery (+15%)</span>
                  </label>
                </div>
              </div>

              <div className="flex space-x-3 pt-4">
                <button 
                  onClick={() => setShowCart(false)}
                  className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer"
                >
                  Continue Shopping
                </button>
                <button className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
                  Place Reorder
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <button 
            onClick={() => setShowNewOrderForm(true)}
            className="flex flex-col items-center p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-400 hover:bg-blue-50 transition-all cursor-pointer"
          >
            <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-full mb-3">
              <i className="ri-add-line text-blue-600 text-xl"></i>
            </div>
            <span className="font-medium text-gray-900">New Order</span>
            <span className="text-sm text-gray-500">Start fresh order</span>
          </button>
          
          <div className="flex flex-col items-center p-4 border-2 border-dashed border-gray-300 rounded-lg">
            <div className="w-12 h-12 flex items-center justify-center bg-green-100 rounded-full mb-3">
              <i className="ri-time-line text-green-600 text-xl"></i>
            </div>
            <span className="font-medium text-gray-900">Faster Processing</span>
            <span className="text-sm text-gray-500">50% faster processing</span>
          </div>
          
          <div className="flex flex-col items-center p-4 border-2 border-dashed border-gray-300 rounded-lg">
            <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-full mb-3">
              <i className="ri-price-tag-line text-blue-600 text-xl"></i>
            </div>
            <span className="font-medium text-gray-900">Locked Pricing</span>
            <span className="text-sm text-gray-500">90 day price guarantee</span>
          </div>
          
          <div className="flex flex-col items-center p-4 border-2 border-dashed border-gray-300 rounded-lg">
            <div className="w-12 h-12 flex items-center justify-center bg-purple-100 rounded-full mb-3">
              <i className="ri-shield-check-line text-purple-600 text-xl"></i>
            </div>
            <span className="font-medium text-gray-900">Quality Guarantee</span>
            <span className="text-sm text-gray-500">Same quality standards</span>
          </div>
        </div>
      </div>
    </div>
  );
}
