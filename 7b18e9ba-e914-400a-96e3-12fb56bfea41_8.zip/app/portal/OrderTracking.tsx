'use client';

import { useState } from 'react';

export default function OrderTracking() {
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');

  const orders = [
    {
      id: 'TX-4892',
      fabric: 'Organic Cotton Canvas',
      quantity: '4,500m',
      status: 'production',
      statusText: 'In Production',
      progress: 60,
      estimatedDelivery: '2024-06-15',
      value: '$54,000',
      timeline: [
        { stage: 'Order Confirmed', completed: true, date: '2024-05-10' },
        { stage: 'Fabric Cutting', completed: true, date: '2024-05-15' },
        { stage: 'Dyeing', completed: true, date: '2024-05-20' },
        { stage: 'Quality Check', completed: false, date: '2024-06-05' },
        { stage: 'Packaging', completed: false, date: '2024-06-10' },
        { stage: 'Shipping', completed: false, date: '2024-06-12' }
      ]
    },
    {
      id: 'TX-4891',
      fabric: 'Athletic Performance Mesh',
      quantity: '2,100m',
      status: 'shipped',
      statusText: 'Shipped',
      progress: 90,
      estimatedDelivery: '2024-06-08',
      value: '$39,375',
      timeline: [
        { stage: 'Order Confirmed', completed: true, date: '2024-04-20' },
        { stage: 'Fabric Cutting', completed: true, date: '2024-04-25' },
        { stage: 'Dyeing', completed: true, date: '2024-05-01' },
        { stage: 'Quality Check', completed: true, date: '2024-05-08' },
        { stage: 'Packaging', completed: true, date: '2024-05-15' },
        { stage: 'Shipping', completed: true, date: '2024-05-20' }
      ]
    },
    {
      id: 'TX-4890',
      fabric: 'Medical Grade Antimicrobial',
      quantity: '800m',
      status: 'delivered',
      statusText: 'Delivered',
      progress: 100,
      estimatedDelivery: '2024-05-25',
      value: '$19,920',
      timeline: [
        { stage: 'Order Confirmed', completed: true, date: '2024-04-01' },
        { stage: 'Fabric Cutting', completed: true, date: '2024-04-05' },
        { stage: 'Dyeing', completed: true, date: '2024-04-10' },
        { stage: 'Quality Check', completed: true, date: '2024-04-15' },
        { stage: 'Packaging', completed: true, date: '2024-04-20' },
        { stage: 'Shipping', completed: true, date: '2024-04-22' }
      ]
    },
    {
      id: 'TX-4889',
      fabric: 'Premium Cotton Canvas',
      quantity: '3,200m',
      status: 'pending',
      statusText: 'Pending Approval',
      progress: 10,
      estimatedDelivery: '2024-07-01',
      value: '$40,000',
      timeline: [
        { stage: 'Order Received', completed: true, date: '2024-05-28' },
        { stage: 'Quote Review', completed: false, date: '2024-06-05' },
        { stage: 'Fabric Cutting', completed: false, date: '2024-06-15' },
        { stage: 'Quality Check', completed: false, date: '2024-06-25' },
        { stage: 'Packaging', completed: false, date: '2024-06-28' },
        { stage: 'Shipping', completed: false, date: '2024-06-30' }
      ]
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'yellow';
      case 'production': return 'blue';
      case 'shipped': return 'orange';
      case 'delivered': return 'green';
      default: return 'gray';
    }
  };

  const filteredOrders = filterStatus === 'all' 
    ? orders 
    : orders.filter(order => order.status === filterStatus);

  const OrderMap = ({ order }) => (
    <div className="bg-gray-100 rounded-lg p-4 mb-4">
      <h4 className="font-semibold text-gray-900 mb-3">Supply Chain Tracking</h4>
      <div className="bg-white rounded-lg overflow-hidden">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.184444444444!2d-74.00994444444444!3d40.71277777777778!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDQyJzQ2LjAiTiA3NMKwMDAnMzUuOCJX!5e0!3m2!1sen!2sus!4v1234567890"
          width="100%" 
          height="300" 
          style={{ border: 0 }}
          allowFullScreen="" 
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
      <div className="flex items-center justify-between mt-3 text-sm">
        <span className="flex items-center text-gray-600">
          <div className="w-4 h-4 flex items-center justify-center mr-2">
            <i className="ri-map-pin-line"></i>
          </div>
          Current Location: Port of New York
        </span>
        <span className="text-blue-600 font-medium">
          Estimated Arrival: {order.estimatedDelivery}
        </span>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-900">Order Tracking</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-8"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="production">In Production</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
          </select>
          <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer">
            <div className="w-4 h-4 flex items-center justify-center">
              <i className="ri-download-line"></i>
            </div>
            <span className="whitespace-nowrap">Export</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order Details</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Progress</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{order.id}</div>
                          <div className="text-sm text-gray-500">{order.fabric}</div>
                          <div className="text-sm text-gray-500">{order.quantity} • {order.value}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-${getStatusColor(order.status)}-100 text-${getStatusColor(order.status)}-800`}>
                          {order.statusText}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`bg-${getStatusColor(order.status)}-600 h-2 rounded-full`}
                            style={{ width: `${order.progress}%` }}
                          ></div>
                        </div>
                        <div className="text-sm text-gray-500 mt-1">{order.progress}% Complete</div>
                      </td>
                      <td className="px-6 py-4">
                        <button 
                          onClick={() => setSelectedOrder(selectedOrder === order.id ? null : order.id)}
                          className="text-blue-600 hover:text-blue-800 font-medium text-sm cursor-pointer"
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {selectedOrder && (
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Order {selectedOrder}</h3>
                <button 
                  onClick={() => setSelectedOrder(null)}
                  className="text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <div className="w-5 h-5 flex items-center justify-center">
                    <i className="ri-close-line"></i>
                  </div>
                </button>
              </div>

              {(() => {
                const order = orders.find(o => o.id === selectedOrder);
                if (!order) return null;

                return (
                  <div className="space-y-4">
                    <OrderMap order={order} />
                    
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Production Timeline</h4>
                      <div className="space-y-3">
                        {order.timeline.map((stage, index) => (
                          <div key={index} className="flex items-center space-x-3">
                            <div className={`w-8 h-8 flex items-center justify-center rounded-full ${
                              stage.completed 
                                ? 'bg-green-100 text-green-600' 
                                : 'bg-gray-100 text-gray-400'
                            }`}>
                              {stage.completed ? (
                                <i className="ri-check-line"></i>
                              ) : (
                                <i className="ri-time-line"></i>
                              )}
                            </div>
                            <div className="flex-1">
                              <div className={`font-medium ${
                                stage.completed ? 'text-gray-900' : 'text-gray-500'
                              }`}>
                                {stage.stage}
                              </div>
                              <div className="text-sm text-gray-500">{stage.date}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-200">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Quantity:</span>
                          <div className="font-medium">{order.quantity}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Value:</span>
                          <div className="font-medium">{order.value}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Delivery:</span>
                          <div className="font-medium">{order.estimatedDelivery}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Progress:</span>
                          <div className="font-medium">{order.progress}%</div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Stats</h3>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Total Active Orders</span>
                <span className="font-semibold">15</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Orders This Month</span>
                <span className="font-semibold">8</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">On-Time Delivery Rate</span>
                <span className="font-semibold text-green-600">98%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Average Lead Time</span>
                <span className="font-semibold">3.2 weeks</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}