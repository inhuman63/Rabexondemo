'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function NewOrderForm({ onClose }) {
  const [formData, setFormData] = useState({
    fabricType: '',
    quantity: '',
    specifications: {
      threadCount: '',
      weight: '',
      composition: '',
      color: ''
    },
    deliveryDate: '',
    specialRequirements: '',
    contactInfo: {
      name: '',
      email: '',
      company: '',
      phone: ''
    }
  });

  const [currentStep, setCurrentStep] = useState(1);

  const fabricTypes = [
    { id: 'cotton', name: 'Premium Cotton Canvas', price: '$12.50/m', minOrder: '500m' },
    { id: 'athletic', name: 'Athletic Performance Mesh', price: '$18.75/m', minOrder: '300m' },
    { id: 'medical', name: 'Medical Grade Antimicrobial', price: '$24.90/m', minOrder: '200m' },
    { id: 'organic', name: 'Organic Cotton Twill', price: '$14.20/m', minOrder: '400m' },
    { id: 'lycra', name: 'High-Performance Lycra', price: '$22.40/m', minOrder: '250m' },
    { id: 'technical', name: 'Flame Retardant Technical', price: '$32.80/m', minOrder: '150m' }
  ];

  const handleInputChange = (section, field, value) => {
    if (section) {
      setFormData(prev => ({
        ...prev,
        [section]: {
          ...prev[section],
          [field]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('New order submitted:', formData);
    // Handle form submission
    alert('Order submitted successfully! We will contact you within 24 hours.');
    onClose();
  };

  const nextStep = () => {
    if (currentStep < 3) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const selectedFabric = fabricTypes.find(fabric => fabric.id === formData.fabricType);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Create New Order</h2>
              <p className="text-gray-600">Step {currentStep} of 3</p>
            </div>
            <button 
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 cursor-pointer"
            >
              <div className="w-6 h-6 flex items-center justify-center">
                <i className="ri-close-line"></i>
              </div>
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-4">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${
                currentStep >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                1
              </div>
              <div className={`w-16 h-0.5 ${currentStep >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${
                currentStep >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                2
              </div>
              <div className={`w-16 h-0.5 ${currentStep >= 3 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${
                currentStep >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                3
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            {currentStep === 1 && (
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Select Fabric Type</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {fabricTypes.map((fabric) => (
                    <div
                      key={fabric.id}
                      className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                        formData.fabricType === fabric.id
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => handleInputChange(null, 'fabricType', fabric.id)}
                    >
                      <h4 className="font-semibold text-gray-900">{fabric.name}</h4>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-blue-600 font-semibold">{fabric.price}</span>
                        <span className="text-sm text-gray-600">Min: {fabric.minOrder}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-5 h-5 flex items-center justify-center mt-0.5">
                      <i className="ri-information-line text-blue-600"></i>
                    </div>
                    <div>
                      <p className="text-sm text-blue-800">
                        Need help choosing the right fabric? 
                        <Link href="/consultation" className="font-semibold hover:underline ml-1">
                          Schedule a consultation
                        </Link>
                        or 
                        <Link href="/products" className="font-semibold hover:underline ml-1">
                          browse our catalog
                        </Link>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Order Specifications</h3>
                
                {selectedFabric && (
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Selected: {selectedFabric.name}</h4>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Price: {selectedFabric.price}</span>
                      <span>Minimum Order: {selectedFabric.minOrder}</span>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Quantity (meters) *
                    </label>
                    <input
                      type="number"
                      value={formData.quantity}
                      onChange={(e) => handleInputChange(null, 'quantity', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter quantity"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Required Delivery Date
                    </label>
                    <input
                      type="date"
                      value={formData.deliveryDate}
                      onChange={(e) => handleInputChange(null, 'deliveryDate', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      min={new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Thread Count
                    </label>
                    <input
                      type="text"
                      value={formData.specifications.threadCount}
                      onChange={(e) => handleInputChange('specifications', 'threadCount', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="e.g., 144×72"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Weight (GSM)
                    </label>
                    <input
                      type="text"
                      value={formData.specifications.weight}
                      onChange={(e) => handleInputChange('specifications', 'weight', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="e.g., 210 GSM"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Composition
                    </label>
                    <input
                      type="text"
                      value={formData.specifications.composition}
                      onChange={(e) => handleInputChange('specifications', 'composition', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="e.g., 98% Cotton, 2% Spandex"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Color
                    </label>
                    <input
                      type="text"
                      value={formData.specifications.color}
                      onChange={(e) => handleInputChange('specifications', 'color', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="e.g., Natural Beige"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Special Requirements
                  </label>
                  <textarea
                    value={formData.specialRequirements}
                    onChange={(e) => handleInputChange(null, 'specialRequirements', e.target.value)}
                    rows="4"
                    maxLength="500"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    placeholder="Any specific requirements, certifications needed, or additional notes..."
                  />
                  <div className="text-right text-xs text-gray-500 mt-1">
                    {formData.specialRequirements.length}/500
                  </div>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Contact Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={formData.contactInfo.name}
                      onChange={(e) => handleInputChange('contactInfo', 'name', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.contactInfo.email}
                      onChange={(e) => handleInputChange('contactInfo', 'email', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Company Name
                    </label>
                    <input
                      type="text"
                      value={formData.contactInfo.company}
                      onChange={(e) => handleInputChange('contactInfo', 'company', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={formData.contactInfo.phone}
                      onChange={(e) => handleInputChange('contactInfo', 'phone', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Order Summary</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Fabric:</span>
                      <span className="font-medium">{selectedFabric?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Quantity:</span>
                      <span className="font-medium">{formData.quantity}m</span>
                    </div>
                    {selectedFabric && formData.quantity && (
                      <div className="flex justify-between border-t border-gray-200 pt-3">
                        <span className="font-semibold">Estimated Total:</span>
                        <span className="font-bold text-blue-600">
                          ${(parseFloat(selectedFabric.price.replace('$', '').replace('/m', '')) * parseInt(formData.quantity || 0)).toLocaleString()}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-between pt-6 border-t border-gray-200">
              <div>
                {currentStep > 1 && (
                  <button 
                    type="button"
                    onClick={prevStep}
                    className="px-6 py-3 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer"
                  >
                    Previous
                  </button>
                )}
              </div>
              <div className="space-x-3">
                <button 
                  type="button"
                  onClick={onClose}
                  className="px-6 py-3 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer"
                >
                  Cancel
                </button>
                {currentStep < 3 ? (
                  <button 
                    type="button"
                    onClick={nextStep}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer"
                    disabled={currentStep === 1 && !formData.fabricType}
                  >
                    Next Step
                  </button>
                ) : (
                  <button 
                    type="submit"
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer"
                    disabled={!formData.contactInfo.name || !formData.contactInfo.email || !formData.quantity}
                  >
                    Submit Order
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}