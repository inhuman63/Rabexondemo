'use client';

import { useState } from 'react';

export default function ReportDownloader({ isOpen, onClose }) {
  const [selectedReports, setSelectedReports] = useState([]);
  const [dateRange, setDateRange] = useState({
    startDate: '',
    endDate: ''
  });
  const [reportFormat, setReportFormat] = useState('pdf');
  const [isGenerating, setIsGenerating] = useState(false);

  const availableReports = [
    {
      id: 'order-summary',
      name: 'Order Summary Report',
      description: 'Complete overview of all orders including status, amounts, and delivery dates',
      category: 'Orders',
      icon: 'ri-shopping-bag-line',
      size: '~2.5MB'
    },
    {
      id: 'financial-statement',
      name: 'Financial Statement',
      description: 'Detailed breakdown of payments, invoices, and account balances',
      category: 'Finance',
      icon: 'ri-money-dollar-circle-line',
      size: '~1.8MB'
    },
    {
      id: 'inventory-usage',
      name: 'Inventory Usage Report',
      description: 'Analysis of fabric consumption patterns and inventory turnover',
      category: 'Inventory',
      icon: 'ri-bar-chart-line',
      size: '~3.2MB'
    },
    {
      id: 'quality-compliance',
      name: 'Quality & Compliance Report',
      description: 'Quality test results, certifications, and compliance documentation',
      category: 'Quality',
      icon: 'ri-shield-check-line',
      size: '~4.1MB'
    },
    {
      id: 'delivery-performance',
      name: 'Delivery Performance Report',
      description: 'Shipping timelines, delivery accuracy, and logistics performance metrics',
      category: 'Logistics',
      icon: 'ri-truck-line',
      size: '~2.1MB'
    },
    {
      id: 'vendor-analysis',
      name: 'Vendor Analysis Report',
      description: 'Supplier performance evaluation and procurement analytics',
      category: 'Procurement',
      icon: 'ri-building-line',
      size: '~2.8MB'
    }
  ];

  const reportCategories = [...new Set(availableReports.map(report => report.category))];

  const handleReportToggle = (reportId) => {
    setSelectedReports(prev => 
      prev.includes(reportId) 
        ? prev.filter(id => id !== reportId)
        : [...prev, reportId]
    );
  };

  const handleSelectAll = (category) => {
    const categoryReports = availableReports
      .filter(report => report.category === category)
      .map(report => report.id);
    
    const allSelected = categoryReports.every(id => selectedReports.includes(id));
    
    if (allSelected) {
      setSelectedReports(prev => prev.filter(id => !categoryReports.includes(id)));
    } else {
      setSelectedReports(prev => [...new Set([...prev, ...categoryReports])]);
    }
  };

  const handleGenerateReports = async () => {
    if (selectedReports.length === 0) return;
    
    setIsGenerating(true);
    
    // Simulate report generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Create mock download
    const selectedReportNames = availableReports
      .filter(report => selectedReports.includes(report.id))
      .map(report => report.name);
    
    const reportData = {
      reports: selectedReportNames,
      dateRange: dateRange,
      format: reportFormat,
      generatedAt: new Date().toISOString(),
      client: 'TextileCorp Procurement Team'
    };
    
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `textile-reports-${new Date().toISOString().split('T')[0]}.${reportFormat}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    setIsGenerating(false);
    onClose();
  };

  const getTotalSize = () => {
    return availableReports
      .filter(report => selectedReports.includes(report.id))
      .reduce((total, report) => {
        const size = parseFloat(report.size.replace('~', '').replace('MB', ''));
        return total + size;
      }, 0)
      .toFixed(1);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Download Reports</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer"
          >
            <i className="ri-close-line text-xl"></i>
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Reports</h3>
                
                {reportCategories.map(category => {
                  const categoryReports = availableReports.filter(report => report.category === category);
                  const allSelected = categoryReports.every(report => selectedReports.includes(report.id));
                  
                  return (
                    <div key={category} className="mb-6">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-gray-800">{category}</h4>
                        <button
                          onClick={() => handleSelectAll(category)}
                          className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap"
                        >
                          {allSelected ? 'Deselect All' : 'Select All'}
                        </button>
                      </div>
                      
                      <div className="space-y-2">
                        {categoryReports.map(report => (
                          <div
                            key={report.id}
                            className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                              selectedReports.includes(report.id)
                                ? 'border-blue-500 bg-blue-50'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => handleReportToggle(report.id)}
                          >
                            <div className="flex items-start space-x-3">
                              <div className={`w-8 h-8 flex items-center justify-center rounded-lg ${
                                selectedReports.includes(report.id) 
                                  ? 'bg-blue-100' 
                                  : 'bg-gray-100'
                              }`}>
                                <i className={`${report.icon} text-lg ${
                                  selectedReports.includes(report.id) 
                                    ? 'text-blue-600' 
                                    : 'text-gray-600'
                                }`}></i>
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center justify-between">
                                  <h5 className="font-medium text-gray-900">{report.name}</h5>
                                  <span className="text-xs text-gray-500">{report.size}</span>
                                </div>
                                <p className="text-sm text-gray-600 mt-1">{report.description}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-3">Date Range</h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">From</label>
                    <input
                      type="date"
                      value={dateRange.startDate}
                      onChange={(e) => setDateRange({...dateRange, startDate: e.target.value})}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">To</label>
                    <input
                      type="date"
                      value={dateRange.endDate}
                      onChange={(e) => setDateRange({...dateRange, endDate: e.target.value})}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-3">Format</h4>
                <div className="space-y-2">
                  {['pdf', 'excel', 'csv'].map(format => (
                    <label key={format} className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        value={format}
                        checked={reportFormat === format}
                        onChange={(e) => setReportFormat(e.target.value)}
                        className="mr-2"
                      />
                      <span className="text-sm text-gray-700 capitalize">{format}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-2">Summary</h4>
                <div className="text-sm text-gray-600 space-y-1">
                  <div>Selected: {selectedReports.length} reports</div>
                  <div>Total size: ~{getTotalSize()}MB</div>
                  <div>Format: {reportFormat.toUpperCase()}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
          <div className="text-sm text-gray-600">
            {selectedReports.length} reports selected
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 cursor-pointer whitespace-nowrap"
            >
              Cancel
            </button>
            <button
              onClick={handleGenerateReports}
              disabled={selectedReports.length === 0 || isGenerating}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 whitespace-nowrap cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <i className="ri-loader-line animate-spin"></i>
                  <span>Generating...</span>
                </>
              ) : (
                <>
                  <i className="ri-download-line"></i>
                  <span>Download Reports</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}