'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import DashboardOverview from './DashboardOverview';
import OrderTracking from './OrderTracking';
import DocumentVault from './DocumentVault';
import ReorderModule from './ReorderModule';
import NewOrderForm from './NewOrderForm';
import ReportDownloader from './ReportDownloader';
import { useState } from 'react';

export default function ClientPortalPage() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showNewOrderForm, setShowNewOrderForm] = useState(false);
  const [showReportDownloader, setShowReportDownloader] = useState(false);

  const tabs = [
    { id: 'dashboard', name: 'Dashboard', icon: 'ri-dashboard-line' },
    { id: 'orders', name: 'Orders', icon: 'ri-truck-line' },
    { id: 'documents', name: 'Documents', icon: 'ri-folder-line' },
    { id: 'reorder', name: 'Reorder', icon: 'ri-refresh-line' }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardOverview 
          onNewOrder={() => setShowNewOrderForm(true)} 
          onDownloadReports={() => setShowReportDownloader(true)}
        />;
      case 'orders':
        return <OrderTracking />;
      case 'documents':
        return <DocumentVault />;
      case 'reorder':
        return <ReorderModule />;
      default:
        return <DashboardOverview 
          onNewOrder={() => setShowNewOrderForm(true)} 
          onDownloadReports={() => setShowReportDownloader(true)}
        />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-8">
        <div className="mx-auto px-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Client Portal</h1>
            <p className="text-gray-600">Manage your orders, documents, and account details</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border mb-8">
            <div className="border-b border-gray-200">
              <nav className="flex space-x-8 px-6">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                      activeTab === tab.id
                        ? 'border-blue-600 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <div className="w-5 h-5 flex items-center justify-center">
                      <i className={tab.icon}></i>
                    </div>
                    <span>{tab.name}</span>
                  </button>
                ))}
              </nav>
            </div>
            
            <div className="p-6">
              {renderContent()}
            </div>
          </div>
        </div>
      </div>

      {showNewOrderForm && (
        <NewOrderForm onClose={() => setShowNewOrderForm(false)} />
      )}

      {showReportDownloader && (
        <ReportDownloader 
          isOpen={showReportDownloader} 
          onClose={() => setShowReportDownloader(false)} 
        />
      )}

      <Footer />
    </div>
  );
}