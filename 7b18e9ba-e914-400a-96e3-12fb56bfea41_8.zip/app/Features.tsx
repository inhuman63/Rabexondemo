
'use client';

export default function Features() {
  const features = [
    {
      icon: 'ri-cube-line',
      title: '3D Fabric Visualization',
      description: 'Interactive WebGL-powered fabric inspection with zoom functionality to examine textures and quality in detail.',
      image: 'https://readdy.ai/api/search-image?query=Advanced%203D%20fabric%20visualization%20technology%20showing%20detailed%20textile%20texture%20inspection%20on%20computer%20screen%2C%20professional%20textile%20quality%20control%20laboratory%2C%20high-tech%20fabric%20analysis%20equipment%2C%20modern%20digital%20inspection%20tools%20with%20microscopic%20detail%20view&width=400&height=300&seq=feat1&orientation=landscape'
    },
    {
      icon: 'ri-brain-line',
      title: 'AI-Powered Recommendations',
      description: 'Smart recommendation engine that guides buyers toward the most suitable fabrics based on their specific requirements.',
      image: 'https://readdy.ai/api/search-image?query=AI%20artificial%20intelligence%20technology%20interface%20showing%20fabric%20recommendations%2C%20modern%20digital%20dashboard%20with%20textile%20analytics%2C%20smart%20recommendation%20system%20displaying%20various%20fabric%20options%2C%20professional%20technology%20interface%20with%20blue%20accents&width=400&height=300&seq=feat2&orientation=landscape'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Blockchain Supply Chain',
      description: 'Complete transparency with blockchain-based tracking from raw materials to finished products for quality assurance.',
      image: 'https://readdy.ai/api/search-image?query=Blockchain%20supply%20chain%20tracking%20visualization%20showing%20textile%20production%20stages%2C%20digital%20supply%20chain%20monitoring%20interface%2C%20secure%20tracking%20technology%20for%20textile%20manufacturing%2C%20modern%20logistics%20dashboard&width=400&height=300&seq=feat3&orientation=landscape'
    },
    {
      icon: 'ri-calendar-check-line',
      title: 'Smart Scheduling System',
      description: 'Automated consultation booking with timezone detection, team routing, and integrated calendar management.',
      image: 'https://readdy.ai/api/search-image?query=Smart%20scheduling%20system%20interface%20showing%20calendar%20management%20for%20business%20consultations%2C%20professional%20appointment%20booking%20dashboard%2C%20modern%20scheduling%20technology%20with%20calendar%20integration%2C%20clean%20business%20interface&width=400&height=300&seq=feat4&orientation=landscape'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Advanced Technology Platform
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Revolutionizing textile manufacturing with cutting-edge technology to enhance user experience and streamline operations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col lg:flex-row items-center space-y-6 lg:space-y-0 lg:space-x-8">
              <div className="lg:w-1/2">
                <img 
                  src={feature.image}
                  alt={feature.title}
                  className="w-full h-64 object-cover object-top rounded-lg shadow-lg"
                />
              </div>
              <div className="lg:w-1/2 text-center lg:text-left">
                <div className="w-16 h-16 flex items-center justify-center bg-blue-100 rounded-full mx-auto lg:mx-0 mb-6">
                  <i className={`${feature.icon} text-2xl text-blue-700`}></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
