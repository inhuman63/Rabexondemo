
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductHero from './ProductHero';
import ProductGrid from './ProductGrid';
import FabricExplorer from './FabricExplorer';

export default function ProductsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <ProductHero />
      <FabricExplorer />
      <ProductGrid />
      <Footer />
    </div>
  );
}
