
'use client';

import { useState } from 'react';
import SampleRequestModal from './SampleRequestModal';

export default function ProductGrid() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [sampleModal, setSampleModal] = useState({
    isOpen: false,
    product: null as any
  });

  const categories = [
    { id: 'all', name: 'All Products' },
    { id: 'cotton', name: 'Cotton' },
    { id: 'sportswear', name: 'Sportswear' },
    { id: 'medical', name: 'Medical' },
    { id: 'technical', name: 'Technical' }
  ];

  const products = [
    {
      id: 1,
      name: 'Premium Cotton Canvas',
      category: 'cotton',
      price: '$12.50/m',
      threadCount: '144×72',
      weight: '210 GSM',
      minOrder: '500m',
      certifications: ['OEKO-TEX]', 'GOTS'],
      image: 'https://readdy.ai/api/search-image?query=Premium%20cotton%20canvas%20fabric%20in%20natural%20beige%20color%20showing%20detailed%20texture%20and%20weave%20pattern%2C%20high-quality%20cotton%20textile%20for%20fashion%20applications%2C%20professional%20fabric%20photography%20with%20soft%20lighting&width=400&height=300&seq=prod1&orientation=landscape'
    },
    {
      id: 2,
      name: 'Athletic Performance Mesh',
      category: 'sportswear',
      price: '$18.75/m',
      threadCount: '180×96',
      weight: '185 GSM',
      minOrder: '300m',
      certifications: ['STANDARD 100', 'Bluesign'],
      image: 'https://readdy.ai/api/search-image?query=Athletic%20performance%20mesh%20fabric%20in%20dark%20blue%20color%20showing%20breathable%20texture%20for%20sportswear%2C%20technical%20athletic%20material%20with%20moisture-wicking%20properties%2C%20professional%20sports%20textile%20photography&width=400&height=300&seq=prod2&orientation=landscape'
    },
    {
      id: 3,
      name: 'Medical Grade Antimicrobial',
      category: 'medical',
      price: '$24.90/m',
      threadCount: '200×120',
      weight: '150 GSM',
      minOrder: '200m',
      certifications: ['ISO 13485', 'FDA Approved'],
      image: 'https://readdy.ai/api/search-image?query=Medical%20grade%20antimicrobial%20fabric%20in%20sterile%20white%20color%2C%20healthcare%20textile%20material%20with%20clean%20uniform%20texture%2C%20professional%20medical%20fabric%20for%20hospital%20applications&width=400&height=300&seq=prod3&orientation=landscape'
    },
    {
      id: 4,
      name: 'Organic Cotton Twill',
      category: 'cotton',
      price: '$14.20/m',
      threadCount: '120×80',
      weight: '230 GSM',
      minOrder: '400m',
      certifications: ['GOTS', 'Organic Content'],
      image: 'https://readdy.ai/api/search-image?query=Organic%20cotton%20twill%20fabric%20in%20natural%20brown%20color%20showing%20diagonal%20weave%20pattern%2C%20sustainable%20cotton%20textile%20with%20eco-friendly%20properties%2C%20professional%20organic%20fabric%20photography&width=400&height=300&seq=prod4&orientation=landscape'
    },
    {
      id: 5,
      name: 'High-Performance Lycra',
      category: 'sportswear',
      price: '$22.40/m',
      threadCount: '160×90',
      weight: '195 GSM',
      minOrder: '250m',
      certifications: ['STANDARD 100', 'Lycra'],
      image: 'https://readdy.ai/api/search-image?query=High-performance%20Lycra%20fabric%20in%20black%20color%20showing%20stretch%20properties%2C%20athletic%20material%20with%20four-way%20stretch%20for%20sportswear%2C%20professional%20technical%20textile%20photography&width=400&height=300&seq=prod5&orientation=landscape'
    },
    {
      id: 6,
      name: 'Flame Retardant Technical',
      category: 'technical',
      price: '$32.80/m',
      threadCount: '200×150',
      weight: '280 GSM',
      minOrder: '150m',
      certifications: ['EN ISO 11612', 'NFPA 2112'],
      image: 'https://readdy.ai/api/search-image?query=Flame%20retardant%20technical%20fabric%20in%20dark%20gray%20color%2C%20industrial%20safety%20textile%20with%20protective%20properties%2C%20professional%20technical%20fabric%20for%20workwear%20applications&width=400&height=300&seq=prod6&orientation=landscape'
    },
    {
      id: 7,
      name: 'Surgical Drape Material',
      category: 'medical',
      price: '$28.50/m',
      threadCount: '180×110',
      weight: '120 GSM',
      minOrder: '300m',
      certifications: ['ISO 13485', 'CE Marked'],
      image: 'https://readdy.ai/api/search-image?query=Surgical%20drape%20material%20in%20sterile%20blue%20color%2C%20medical%20textile%20for%20surgical%20applications%2C%20professional%20healthcare%20fabric%20with%20barrier%20properties&width=400&height=300&seq=prod7&orientation=landscape'
    },
    {
      id: 8,
      name: 'Carbon Fiber Composite',
      category: 'technical',
      price: '$45.60/m',
      threadCount: '240×180',
      weight: '320 GSM',
      minOrder: '100m',
      certifications: ['ASTM D3039', 'ISO 14126'],
      image: 'https://readdy.ai/api/search-image?query=Carbon%20fiber%20composite%20fabric%20showing%20distinctive%20black%20weave%20pattern%2C%20high-tech%20industrial%20material%20for%20aerospace%20applications%2C%20professional%20technical%20textile%20with%20geometric%20pattern&width=400&height=300&seq=prod8&orientation=landscape'
    }
  ];

  const filteredProducts = activeCategory === 'all' 
    ? products 
    : products.filter(product => product.category === activeCategory);

  const handleSampleRequest = (product: any) => {
    setSampleModal({
      isOpen: true,
      product: product
    });
  };

  const closeSampleModal = () => {
    setSampleModal({
      isOpen: false,
      product: null
    });
  };

  return (
    <>
      <section className="py-20 bg-white">
        <div className="mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Complete Product Catalog
            </h2>
            <p className="text-xl text-gray-600">
              Browse our extensive collection of premium textiles
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-3 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeCategory === category.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <div key={product.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                <img 
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover object-top"
                />
                <div className="p-4">
                  <h3 className="font-bold text-gray-900 mb-2">{product.name}</h3>
                  <div className="text-2xl font-bold text-blue-600 mb-3">{product.price}</div>
                  
                  <div className="space-y-1 mb-4 text-sm text-gray-600">
                    <div className="flex justify-between">
                      <span>Thread Count:</span>
                      <span className="font-medium">{product.threadCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Weight:</span>
                      <span className="font-medium">{product.weight}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Min. Order:</span>
                      <span className="font-medium">{product.minOrder}</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex flex-wrap gap-1">
                      {product.certifications.slice(0, 2).map((cert, index) => (
                        <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium">
                          {cert}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <button className="w-full bg-blue-600 text-white py-2 rounded font-medium hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
                      View Details
                    </button>
                    <button 
                      onClick={() => handleSampleRequest(product)}
                      className="w-full bg-gray-100 text-gray-700 py-2 rounded font-medium hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer"
                    >
                      Request Sample
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
              Load More Products
            </button>
          </div>
        </div>
      </section>

      <SampleRequestModal 
        isOpen={sampleModal.isOpen}
        onClose={closeSampleModal}
        product={sampleModal.product}
      />
    </>
  );
}
