'use client';

import { useState } from 'react';

interface SampleRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: {
    id: number;
    name: string;
    price: string;
    image: string;
  } | null;
}

export default function SampleRequestModal({ isOpen, onClose, product }: SampleRequestModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    postalCode: '',
    sampleSize: '10x10cm',
    quantity: '1',
    urgency: 'standard',
    purpose: '',
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const sampleSizes = [
    { id: '10x10cm', name: '10cm × 10cm', price: 'Free' },
    { id: '20x20cm', name: '20cm × 20cm', price: '$5' },
    { id: '30x30cm', name: '30cm × 30cm', price: '$12' },
    { id: 'a4', name: 'A4 Size (21×30cm)', price: '$18' }
  ];

  const urgencyOptions = [
    { id: 'standard', name: 'Standard (7-10 days)', cost: 'Free' },
    { id: 'express', name: 'Express (3-5 days)', cost: '+$15' },
    { id: 'urgent', name: 'Urgent (1-2 days)', cost: '+$35' }
  ];

  const purposes = [
    'Quality Testing',
    'Color Matching',
    'Feel & Texture',
    'Client Approval',
    'Production Planning',
    'Other'
  ];

  if (!isOpen || !product) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setSubmitted(true);
    setIsSubmitting(false);
    
    setTimeout(() => {
      onClose();
      setSubmitted(false);
      setFormData({
        name: '',
        email: '',
        company: '',
        phone: '',
        address: '',
        city: '',
        country: '',
        postalCode: '',
        sampleSize: '10x10cm',
        quantity: '1',
        urgency: 'standard',
        purpose: '',
        notes: ''
      });
    }, 3000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const selectedSize = sampleSizes.find(s => s.id === formData.sampleSize);
  const selectedUrgency = urgencyOptions.find(u => u.id === formData.urgency);

  if (submitted) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="ri-check-line text-2xl text-green-600"></i>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Sample Request Sent!</h3>
          <p className="text-gray-600 mb-4">
            Your sample request has been submitted successfully. We'll prepare and ship your sample within the selected timeframe.
          </p>
          <p className="text-sm text-gray-500">
            Tracking information will be sent to your email address.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">Request Sample</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-gray-700 cursor-pointer"
          >
            <i className="ri-close-line text-xl"></i>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
          <div className="p-6 border-r border-gray-200">
            <div className="mb-6">
              <img 
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover object-top rounded-lg mb-4"
              />
              <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
              <div className="text-lg font-semibold text-blue-600">{product.price}</div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Sample Size
                </label>
                <div className="space-y-2">
                  {sampleSizes.map((size) => (
                    <label key={size.id} className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <div className="flex items-center">
                        <input
                          type="radio"
                          name="sampleSize"
                          value={size.id}
                          checked={formData.sampleSize === size.id}
                          onChange={handleInputChange}
                          className="mr-3"
                        />
                        <span className="font-medium">{size.name}</span>
                      </div>
                      <span className="text-sm text-blue-600 font-semibold">{size.price}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Delivery Speed
                </label>
                <div className="space-y-2">
                  {urgencyOptions.map((option) => (
                    <label key={option.id} className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <div className="flex items-center">
                        <input
                          type="radio"
                          name="urgency"
                          value={option.id}
                          checked={formData.urgency === option.id}
                          onChange={handleInputChange}
                          className="mr-3"
                        />
                        <span className="font-medium">{option.name}</span>
                      </div>
                      <span className="text-sm text-blue-600 font-semibold">{option.cost}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex justify-between items-center text-sm mb-2">
                  <span>Sample Size:</span>
                  <span className="font-medium">{selectedSize?.name}</span>
                </div>
                <div className="flex justify-between items-center text-sm mb-2">
                  <span>Delivery:</span>
                  <span className="font-medium">{selectedUrgency?.name}</span>
                </div>
                <div className="flex justify-between items-center font-bold text-blue-600 border-t border-blue-200 pt-2 mt-2">
                  <span>Total Cost:</span>
                  <span>
                    {selectedSize?.price === 'Free' && selectedUrgency?.cost === 'Free' 
                      ? 'Free' 
                      : `${selectedSize?.price === 'Free' ? '$0' : selectedSize?.price} ${selectedUrgency?.cost !== 'Free' ? selectedUrgency?.cost : ''}`}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Company Name
                  </label>
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Shipping Address *
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  placeholder="Street address"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    City *
                  </label>
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Country *
                  </label>
                  <input
                    type="text"
                    name="country"
                    value={formData.country}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Postal Code *
                  </label>
                  <input
                    type="text"
                    name="postalCode"
                    value={formData.postalCode}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Sample Quantity
                  </label>
                  <select
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleInputChange}
                    className="w-full p-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {[1, 2, 3, 4, 5].map(num => (
                      <option key={num} value={num.toString()}>{num} piece{num > 1 ? 's' : ''}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Purpose
                  </label>
                  <select
                    name="purpose"
                    value={formData.purpose}
                    onChange={handleInputChange}
                    className="w-full p-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select purpose</option>
                    {purposes.map(purpose => (
                      <option key={purpose} value={purpose}>{purpose}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Additional Notes
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  rows={3}
                  maxLength={500}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  placeholder="Any specific requirements or questions..."
                />
                <div className="text-right text-xs text-gray-500 mt-1">
                  {formData.notes.length}/500
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting || !formData.name || !formData.email || !formData.address || !formData.city || !formData.country || !formData.postalCode}
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
              >
                {isSubmitting ? 'Processing...' : 'Request Sample'}
              </button>

              <p className="text-xs text-gray-500 text-center">
                By submitting this request, you agree to our terms of service and privacy policy.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}