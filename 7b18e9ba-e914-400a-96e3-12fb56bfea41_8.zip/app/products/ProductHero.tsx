
'use client';

export default function ProductHero() {
  return (
    <section 
      className="relative py-32 bg-cover bg-center"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Premium%20textile%20fabric%20showcase%20with%20various%20high-quality%20materials%20displayed%20professionally%2C%20luxury%20fabric%20samples%20in%20different%20textures%20and%20colors%2C%20professional%20textile%20showroom%20with%20elegant%20lighting%2C%20sophisticated%20fabric%20presentation%20for%20fashion%20and%20industrial%20applications&width=1920&height=800&seq=prodhero1&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-gray-900/90 to-gray-900/50"></div>
      
      <div className="relative z-10 mx-auto px-6 text-center">
        <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
          Premium Textile Collection
        </h1>
        <p className="text-xl text-gray-200 mb-8 max-w-3xl mx-auto">
          Explore our comprehensive range of high-quality fabrics with interactive 3D visualization and detailed specifications.
        </p>
        
        <div className="flex flex-wrap justify-center gap-4">
          <div className="bg-white/10 backdrop-blur-sm px-6 py-3 rounded-full border border-white/30">
            <span className="text-white font-medium">150+ Fabric Types</span>
          </div>
          <div className="bg-white/10 backdrop-blur-sm px-6 py-3 rounded-full border border-white/30">
            <span className="text-white font-medium">OEKO-TEX® Certified</span>
          </div>
          <div className="bg-white/10 backdrop-blur-sm px-6 py-3 rounded-full border border-white/30">
            <span className="text-white font-medium">Custom Solutions</span>
          </div>
        </div>
      </div>
    </section>
  );
}
