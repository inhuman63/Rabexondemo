
'use client';

import { useState } from 'react';

export default function FabricExplorer() {
  const [selectedFabric, setSelectedFabric] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(1);

  const fabrics = [
    {
      name: 'Premium Cotton Canvas',
      threadCount: '144×72',
      composition: '98% Cotton, 2% Spandex',
      weight: '210 GSM',
      certifications: ['OEKO-TEX®', 'GOTS'],
      minOrder: '500m',
      leadTime: '4-6 weeks',
      price: '$12.50/m',
      image: 'https://readdy.ai/api/search-image?query=High-resolution%20cotton%20canvas%20fabric%20texture%20showing%20detailed%20weave%20pattern%2C%20premium%20cotton%20textile%20with%20visible%20fiber%20structure%2C%20professional%20fabric%20photography%20with%20macro%20detail%2C%20natural%20cotton%20material%20texture%20for%20fashion%20industry&width=600&height=400&seq=fab1&orientation=landscape'
    },
    {
      name: 'Athletic Performance Mesh',
      threadCount: '180×96',
      composition: '92% Polyester, 8% Elastane',
      weight: '185 GSM',
      certifications: ['STANDARD 100', 'Bluesign®'],
      minOrder: '300m',
      leadTime: '3-5 weeks',
      price: '$18.75/m',
      image: 'https://readdy.ai/api/search-image?query=Athletic%20performance%20mesh%20fabric%20showing%20breathable%20texture%20and%20stretch%20properties%2C%20technical%20sportswear%20material%20with%20moisture-wicking%20capabilities%2C%20high-performance%20athletic%20textile%20with%20fine%20mesh%20structure&width=600&height=400&seq=fab2&orientation=landscape'
    },
    {
      name: 'Medical Grade Antimicrobial',
      threadCount: '200×120',
      composition: '100% Antimicrobial Polyester',
      weight: '150 GSM',
      certifications: ['ISO 13485', 'FDA Approved'],
      minOrder: '200m',
      leadTime: '2-4 weeks',
      price: '$24.90/m',
      image: 'https://readdy.ai/api/search-image?query=Medical%20grade%20antimicrobial%20fabric%20with%20sterile%20properties%2C%20healthcare%20textile%20material%20showing%20clean%20uniform%20texture%2C%20professional%20medical%20fabric%20with%20fine%20weave%20for%20medical%20applications&width=600&height=400&seq=fab3&orientation=landscape'
    }
  ];

  const handleZoom = (direction) => {
    if (direction === 'in' && zoomLevel < 3) {
      setZoomLevel(zoomLevel + 0.5);
    } else if (direction === 'out' && zoomLevel > 1) {
      setZoomLevel(zoomLevel - 0.5);
    }
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            3D Fabric Explorer
          </h2>
          <p className="text-xl text-gray-600">
            Interactive fabric inspection with detailed specifications
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            <div className="relative bg-gray-100 h-96 lg:h-[600px] overflow-hidden">
              <img 
                src={fabrics[selectedFabric].image}
                alt={fabrics[selectedFabric].name}
                className="w-full h-full object-cover object-top transition-transform duration-300"
                style={{ transform: `scale(${zoomLevel})` }}
              />
              
              <div className="absolute top-4 right-4 flex flex-col space-y-2">
                <button 
                  onClick={() => handleZoom('in')}
                  className="w-10 h-10 flex items-center justify-center bg-white/90 backdrop-blur-sm rounded-full shadow-lg hover:bg-white transition-colors cursor-pointer"
                  disabled={zoomLevel >= 3}
                >
                  <i className="ri-add-line text-gray-700"></i>
                </button>
                <button 
                  onClick={() => handleZoom('out')}
                  className="w-10 h-10 flex items-center justify-center bg-white/90 backdrop-blur-sm rounded-full shadow-lg hover:bg-white transition-colors cursor-pointer"
                  disabled={zoomLevel <= 1}
                >
                  <i className="ri-subtract-line text-gray-700"></i>
                </button>
              </div>

              <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-lg">
                <span className="text-sm font-medium text-gray-700">Zoom: {zoomLevel}x</span>
              </div>
            </div>

            <div className="p-8">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  {fabrics[selectedFabric].name}
                </h3>
                <div className="text-3xl font-bold text-blue-600 mb-4">
                  {fabrics[selectedFabric].price}
                </div>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex justify-between py-3 border-b border-gray-200">
                  <span className="text-gray-600">Thread Count</span>
                  <span className="font-semibold">{fabrics[selectedFabric].threadCount}</span>
                </div>
                <div className="flex justify-between py-3 border-b border-gray-200">
                  <span className="text-gray-600">Composition</span>
                  <span className="font-semibold">{fabrics[selectedFabric].composition}</span>
                </div>
                <div className="flex justify-between py-3 border-b border-gray-200">
                  <span className="text-gray-600">Weight</span>
                  <span className="font-semibold">{fabrics[selectedFabric].weight}</span>
                </div>
                <div className="flex justify-between py-3 border-b border-gray-200">
                  <span className="text-gray-600">Min. Order</span>
                  <span className="font-semibold">{fabrics[selectedFabric].minOrder}</span>
                </div>
                <div className="flex justify-between py-3 border-b border-gray-200">
                  <span className="text-gray-600">Lead Time</span>
                  <span className="font-semibold">{fabrics[selectedFabric].leadTime}</span>
                </div>
              </div>

              <div className="mb-8">
                <h4 className="font-semibold text-gray-900 mb-3">Certifications</h4>
                <div className="flex flex-wrap gap-2">
                  {fabrics[selectedFabric].certifications.map((cert, index) => (
                    <span key={index} className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      {cert}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
                  Request Sample
                </button>
                <button className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer">
                  Get Quote
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12">
          <h4 className="text-xl font-semibold text-gray-900 mb-6 text-center">
            Select Fabric to Explore
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {fabrics.map((fabric, index) => (
              <button
                key={index}
                onClick={() => setSelectedFabric(index)}
                className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                  selectedFabric === index 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <img 
                  src={fabric.image}
                  alt={fabric.name}
                  className="w-full h-24 object-cover object-top rounded mb-3"
                />
                <h5 className="font-semibold text-gray-900 text-sm">{fabric.name}</h5>
                <p className="text-blue-600 font-semibold text-sm">{fabric.price}</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
