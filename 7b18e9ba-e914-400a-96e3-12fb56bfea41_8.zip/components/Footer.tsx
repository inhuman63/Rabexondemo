
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="text-2xl font-bold text-blue-400" style={{fontFamily: "Pacifico, serif"}}>
              Rabexon
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Global textile solutions provider since 1995. Delivering premium fabrics with 98% on-time delivery rate.
            </p>
            <div className="flex space-x-4">
              <div className="w-8 h-8 flex items-center justify-center bg-blue-700 rounded cursor-pointer hover:bg-blue-600">
                <i className="ri-linkedin-fill text-white"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-blue-700 rounded cursor-pointer hover:bg-blue-600">
                <i className="ri-twitter-fill text-white"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-blue-700 rounded cursor-pointer hover:bg-blue-600">
                <i className="ri-facebook-fill text-white"></i>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Products</h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><Link href="/products" className="hover:text-white cursor-pointer">Cotton Fabrics</Link></li>
              <li><Link href="/products" className="hover:text-white cursor-pointer">Sportswear Textiles</Link></li>
              <li><Link href="/products" className="hover:text-white cursor-pointer">Medical Textiles</Link></li>
              <li><Link href="/products" className="hover:text-white cursor-pointer">Technical Fabrics</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><Link href="/consultation" className="hover:text-white cursor-pointer">Consultation</Link></li>
              <li><Link href="/consultation" className="hover:text-white cursor-pointer">Custom Solutions</Link></li>
              <li><Link href="/portal" className="hover:text-white cursor-pointer">Client Portal</Link></li>
              <li><Link href="/about" className="hover:text-white cursor-pointer">Quality Assurance</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-center space-x-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-phone-line"></i>
                </div>
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-mail-line"></i>
                </div>
                <span>info@rabexon.com</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-map-pin-line"></i>
                </div>
                <span>New York, NY 10001</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2024 Rabexon Textile Bridge. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
