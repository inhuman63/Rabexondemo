
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="mx-auto px-6">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-blue-700" style={{fontFamily: "Pacifico, serif"}}>
              Rabexon
            </div>
            <span className="text-gray-600 text-sm hidden sm:block">Textile Bridge</span>
          </Link>

          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-700 font-medium whitespace-nowrap cursor-pointer">
              Home
            </Link>
            <Link href="/products" className="text-gray-700 hover:text-blue-700 font-medium whitespace-nowrap cursor-pointer">
              Products
            </Link>
            <Link href="/consultation" className="text-gray-700 hover:text-blue-700 font-medium whitespace-nowrap cursor-pointer">
              Consultation
            </Link>
            <Link href="/portal" className="text-gray-700 hover:text-blue-700 font-medium whitespace-nowrap cursor-pointer">
              Client Portal
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-blue-700 font-medium whitespace-nowrap cursor-pointer">
              About Us
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Link href="/consultation" className="bg-blue-700 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-800 transition-colors whitespace-nowrap cursor-pointer">
              Get Quote
            </Link>
          </div>

          <button 
            className="md:hidden p-2 cursor-pointer"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <div className="w-6 h-6 flex items-center justify-center">
              <i className={isMenuOpen ? "ri-close-line" : "ri-menu-line"}></i>
            </div>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t bg-white">
            <div className="flex flex-col space-y-3">
              <Link href="/" className="text-gray-700 hover:text-blue-700 font-medium px-2 py-1 cursor-pointer">
                Home
              </Link>
              <Link href="/products" className="text-gray-700 hover:text-blue-700 font-medium px-2 py-1 cursor-pointer">
                Products
              </Link>
              <Link href="/consultation" className="text-gray-700 hover:text-blue-700 font-medium px-2 py-1 cursor-pointer">
                Consultation
              </Link>
              <Link href="/portal" className="text-gray-700 hover:text-blue-700 font-medium px-2 py-1 cursor-pointer">
                Client Portal
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-700 font-medium px-2 py-1 cursor-pointer">
                About Us
              </Link>
              <Link href="/consultation" className="bg-blue-700 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-800 transition-colors whitespace-nowrap cursor-pointer mt-2">
                Get Quote
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
